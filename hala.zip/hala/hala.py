import telebot
from flask import Flask, request
import json
import random
import re
import os
from telebot import types
from deep_translator import GoogleTranslator
import time
import uuid
from telebot import types
import requests
import io
from gtts import gTTS
from pydub import AudioSegment
import datetime
import pytz
import subprocess
import threading
import traceback
import shutil
import telebot
import urllib.parse
import logging


# تحقق اذا الملفات موجودة واذا فاضية اعملها
if not os.path.exists("active_chats.json"):
    with open("active_chats.json", "w") as f:
        json.dump({}, f)

if not os.path.exists("users.json"):
    with open("users.json", "w") as f:
        json.dump([], f)

if not os.path.exists("stats.json"):
    with open("stats.json", "w") as f:
        json.dump({"groups": 0, "active_groups": 0, "users": 0}, f)

# إعداد البوت
TOKEN = os.getenv("7536056765:AAFDBIoyZciBqu3PRmdesshVXyJ76MvUSW8")  # Telegram bot token from environment variable
bot = telebot.TeleBot(TOKEN)
app = Flask(__name__)

ADMIN_ID = 7216718830  # عيّن معرف الأدمن الخاص بك

keywords = ["virus", "malware", "trojan", "hack", "phishing", "exploit", "worm"]

@bot.message_handler(content_types=['document'])
def scan_document(message):
    """
    دالة لفحص محتوى الملف باستخدام قائمة الكلمات المحددة.
    يتم تحميل الملف، قراءته (يفترض أن يكون ملف نصي بترميز UTF-8) ثم البحث عن الكلمات.
    بعدها يتم إعداد رسالة النتائج بنفس تنسيق الرسائل الأصلي.
    """
    try:
        # الحصول على الملف وتنزيله
        file_info = bot.get_file(message.document.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        temp_file_path = "temp_" + message.document.file_name

        # حفظ الملف مؤقتاً
        with open(temp_file_path, "wb") as new_file:
            new_file.write(downloaded_file)

        # قراءة محتوى الملف كنص بترميز UTF-8
        with open(temp_file_path, "r", encoding="utf-8") as f:
            file_content = f.read()
    except Exception as e:
        bot.reply_to(message, "فشل قراءة محتوى الملف. تأكد أن الملف نصي وبترميز UTF-8.")
        if os.path.exists(temp_file_path):
            os.remove(temp_file_path)
        return

    # حذف الملف المؤقت بعد القراءة
    os.remove(temp_file_path)

    # فحص المحتوى للبحث عن الكلمات المحددة
    found_keywords = {}
    for word in keywords:
        count = file_content.lower().count(word.lower())
        if count > 0:
            found_keywords[word] = count

    # إعداد النتائج بناءً على وجود الكلمات
    if found_keywords:
        harmless = 0
        malicious = sum(found_keywords.values())
    else:
        harmless = 1
        malicious = 0

    # إعداد قائمتين:
    suspicious = list(found_keywords.keys())  # قائمة الكلمات التي تم العثور عليها
    suspicious_str = " + ".join(suspicious) if suspicious else ""

    # الحصول على معرف المستخدم
    user_mention = f"@{message.from_user.username}" if message.from_user.username else f"اخخ"

    # إعداد رسالة النتائج
    if harmless == 1:
        result_msg = "الملف امن ممتاز 🫶🏻\n"
        result_msg += f"استمر - {user_mention}"
    else:
        result_msg = f"الملف ملغم خطير!!\n"
        result_msg += f"عدد الاوامر الملغمة - {malicious}\n"
        result_msg += f"الاوامر الخطيرة -  {suspicious_str}\n"
        result_msg += f"انت مخالف - {user_mention}"

    bot.reply_to(message, result_msg)

VIP_FILE = 'vip_users.json'
API_BASE_URL = "https://dev-darkcre.pantheonsite.io/API/DARKBLACKGPT.php?text="

# لتخزين الطلبات المعلقة (يمكن استخدام قاموس عالمي)
pending_requests = {}  # مثال: { user_id: { 'cancelled': False, 'waiting_msg_id': ..., 'chat_id': ... } }
# معاجم لتخزين بيانات متعددة
promotion_data = {}      # لتخزين صلاحيات الترقية
warnings_data = {}       # لتخزين التحذيرات: المفتاح f"{chat_id}_{user_id}"
welcome_messages = {}    # لتخزين رسالة الترحيب لكل مجموعة: المفتاح chat_id
group_rules = {}         # لتخزين قوانين المجموعة: المفتاح chat_id
auto_delete_time = {}    # لتعيين وقت الحذف التلقائي للرسائل: المفتاح chat_id
locked_media = {}        # لتخزين أنواع المحتوى المقفلة: المفتاح chat_id (مثلاً: {"photo", "video"})

# قوائم للميمات وصور الأشباح (يمكنك تعديلها)
meme_list = [
    "https://i.imgur.com/xyz1.jpg",
    "https://i.imgur.com/xyz2.jpg",
    "https://i.imgur.com/xyz3.jpg"
]
ghost_images = [
    "https://i.imgur.com/ghost1.jpg",
    "https://i.imgur.com/ghost2.jpg",
    "https://i.imgur.com/ghost3.jpg"
]
eight_ball_answers = [
    "نعم", "لا", "ربما", "اسأل لاحقاً", "بالتأكيد", "غير محتمل"
]

############################################
# دوال مساعدة للرسائل الجميلة وصلاحيات المستخدم
############################################

def send_pretty_message(chat_id, text, reply_markup=None, parse_mode="HTML"):
    bot.send_message(chat_id, text, reply_markup=reply_markup, parse_mode=parse_mode)

def edit_pretty_message(chat_id, message_id, text, reply_markup=None, parse_mode="HTML"):
    try:
        bot.edit_message_text(text, chat_id, message_id, reply_markup=reply_markup, parse_mode=parse_mode)
    except Exception as e:
        if "there is no text in the message to edit" in str(e):
            try:
                bot.edit_message_caption(text, chat_id, message_id, reply_markup=reply_markup, parse_mode=parse_mode)
            except Exception as ex:
                raise ex
        else:
            raise e

def is_bot_admin(chat_id):
    try:
        bot_member = bot.get_chat_member(chat_id, bot.get_me().id)
        return bot_member.status in ["administrator", "creator"]
    except Exception as e:
        print("خطأ عند فحص صلاحيات البوت:", e)
        return False

def is_user_admin(chat_id, user_id):
    try:
        user_member = bot.get_chat_member(chat_id, user_id)
        return user_member.status in ["administrator", "creator"]
    except Exception as e:
        print("خطأ عند فحص صلاحيات المستخدم:", e)
        return False

############################################
# أوامر الإدارة الأساسية (تعمل فقط للمسؤولين)
############################################

@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("حظر"))
def ban_user(message):
    try:
        chat_id = message.chat.id
        if message.chat.type not in ["supergroup", "group"]:
            return

        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return

        if not is_bot_admin(chat_id):
            send_pretty_message(chat_id, "البوت ليس مسؤولاً.")
            return

        if not message.reply_to_message and '@' not in message.text:
            send_pretty_message(chat_id, "يجب الرد على رسالة المستخدم أو ذكر المعرف @ لحظره.")
            return

        user_id = None
        target_username = None

        if message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
        elif '@' in message.text:
            target_username = message.text.split('@')[1].split()[0].lower()
            if not target_username:
                send_pretty_message(chat_id, "يرجى تحديد معرف صحيح بعد @.")
                return

            try:
                # أولاً نحاول البحث بين المشرفين
                admins = bot.get_chat_administrators(chat_id)
                for admin in admins:
                    if admin.user.username and admin.user.username.lower() == target_username:
                        user_id = admin.user.id
                        break

                if not user_id:
                    member = bot.get_chat_member(chat_id, target_username)
                    user_id = member.user.id
            except Exception:
                send_pretty_message(chat_id, f"لا يمكن العثور على @{target_username} في المجموعة.")
                return

        if not user_id:
            send_pretty_message(chat_id, "لم يتم تحديد المستخدم بشكل صحيح.")
            return

        chat_member = bot.get_chat_member(chat_id, user_id)

        if chat_member.status in ["administrator", "creator"]:
            send_pretty_message(chat_id, "🚫 لا يمكن حظر مشرف أو مالك المجموعة!")
            return

        if chat_member.status == "kicked":
            send_pretty_message(chat_id, f"🚫 المستخدم <a href='tg://user?id={user_id}'>{user_id}</a> محظور بالفعل.")
            return

        bot.ban_chat_member(chat_id, user_id)
        name_or_link = f"@{target_username}" if target_username else f"<a href='tg://user?id={user_id}'>المستخدم</a>"
        send_pretty_message(chat_id, f"✅ تم حظر {name_or_link}.")

    except Exception as e:
        print("خطأ في أمر الحظر:", e)
        traceback.print_exc()
        send_pretty_message(message.chat.id, f"في مشكلة: {e}\nحاول مرة تانية.")

@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("الغاء الحظر"))
def unban_user(message):
    try:
        chat_id = message.chat.id
        if message.chat.type not in ["supergroup", "group"]:
            return

        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return

        if not is_bot_admin(chat_id):
            send_pretty_message(chat_id, "البوت ليس مسؤولاً.")
            return

        if not message.reply_to_message and '@' not in message.text:
            send_pretty_message(chat_id, "يجب الرد على رسالة المستخدم أو ذكر المعرف @ لإلغاء حظره.")
            return

        user_id = None
        target_username = None

        if message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
        elif '@' in message.text:
            target_username = message.text.split('@')[1].split()[0].lower()
            if not target_username:
                send_pretty_message(chat_id, "يرجى تحديد معرف صحيح بعد @.")
                return

            try:
                admins = bot.get_chat_administrators(chat_id)
                for admin in admins:
                    if admin.user.username and admin.user.username.lower() == target_username:
                        user_id = admin.user.id
                        break

                if not user_id:
                    member = bot.get_chat_member(chat_id, target_username)
                    user_id = member.user.id
            except Exception:
                send_pretty_message(chat_id, f"لا يمكن العثور على @{target_username} في المجموعة.")
                return

        if not user_id:
            send_pretty_message(chat_id, "لم يتم تحديد المستخدم بشكل صحيح.")
            return

        # محاولة الحصول على حالة العضو
        try:
            member_status = bot.get_chat_member(chat_id, user_id).status
        except:
            member_status = "kicked"  # إذا فشل الحصول عليه، نفترض أنه محظور

        if member_status != "kicked":
            send_pretty_message(chat_id, f"🚫 المستخدم <a href='tg://user?id={user_id}'>هذا</a> ليس محظورًا.")
            return

        bot.unban_chat_member(chat_id, user_id)
        name_or_link = f"@{target_username}" if target_username else f"<a href='tg://user?id={user_id}'>المستخدم</a>"
        send_pretty_message(chat_id, f"✅ تم إلغاء حظر {name_or_link}.")

    except Exception as e:
        print("خطأ في أمر إلغاء الحظر:", e)
        traceback.print_exc()
        send_pretty_message(message.chat.id, f"في مشكلة: {e}\nحاول مرة تانية.")

@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("كتم"))
def mute_user(message):
    try:
        chat_id = message.chat.id
        if message.chat.type not in ["supergroup", "group"]:
            return

        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return

        if not is_bot_admin(chat_id):
            send_pretty_message(chat_id, "البوت ليس مسؤولاً.")
            return

        if not message.reply_to_message and '@' not in message.text:
            send_pretty_message(chat_id, "يجب الرد على رسالة المستخدم أو ذكر المعرف @ لكتمه.")
            return

        user_id = None
        target_username = None

        if message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
        elif '@' in message.text:
            target_username = message.text.split('@')[1].split()[0].lower()
            if not target_username:
                send_pretty_message(chat_id, "يرجى تحديد معرف صحيح بعد @.")
                return

            try:
                admins = bot.get_chat_administrators(chat_id)
                for admin in admins:
                    if admin.user.username and admin.user.username.lower() == target_username:
                        user_id = admin.user.id
                        break

                if not user_id:
                    member = bot.get_chat_member(chat_id, target_username)
                    user_id = member.user.id
            except Exception:
                send_pretty_message(chat_id, f"لا يمكن العثور على @{target_username} في المجموعة.")
                return

        if not user_id:
            send_pretty_message(chat_id, "لم يتم تحديد المستخدم بشكل صحيح.")
            return

        target_member = bot.get_chat_member(chat_id, user_id)

        if target_member.status in ["administrator", "creator"]:
            send_pretty_message(chat_id, "🚫 لا يمكن كتم مشرف أو مالك المجموعة!")
            return

        if hasattr(target_member, 'can_send_messages') and not target_member.can_send_messages:
            send_pretty_message(chat_id, f"🚫 المستخدم <a href='tg://user?id={user_id}'>هذا</a> مكتوم بالفعل.")
            return

        permissions = types.ChatPermissions(can_send_messages=False)
        bot.restrict_chat_member(chat_id, user_id, permissions=permissions)

        name_or_link = f"@{target_username}" if target_username else f"<a href='tg://user?id={user_id}'>المستخدم</a>"
        send_pretty_message(chat_id, f'🤐 تم كتم {name_or_link}.')

    except Exception as e:
        print("خطأ في أمر الكتم:", e)
        traceback.print_exc()
        send_pretty_message(message.chat.id, f"في مشكلة: {e}\nحاول مرة تانية.")

@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("الغاء الكتم"))
def unmute_user(message):
    try:
        chat_id = message.chat.id
        if message.chat.type not in ["supergroup", "group"]:
            return

        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return

        if not is_bot_admin(chat_id):
            send_pretty_message(chat_id, "البوت ليس مسؤولاً.")
            return

        if not message.reply_to_message and '@' not in message.text:
            send_pretty_message(chat_id, "يجب الرد على رسالة المستخدم أو ذكر المعرف @ لإلغاء كتمه.")
            return

        user_id = None
        target_username = None

        if message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
        elif '@' in message.text:
            target_username = message.text.split('@')[1].split()[0].lower()
            if not target_username:
                send_pretty_message(chat_id, "يرجى تحديد معرف صحيح بعد @.")
                return

            # نحاول الحصول على العضو إما من الأدمنية أو من التفاعل
            try:
                admins = bot.get_chat_administrators(chat_id)
                for admin in admins:
                    if admin.user.username and admin.user.username.lower() == target_username:
                        user_id = admin.user.id
                        break

                if not user_id:
                    member = bot.get_chat_member(chat_id, target_username)
                    user_id = member.user.id
            except Exception:
                send_pretty_message(chat_id, f"لا يمكن العثور على @{target_username} في المجموعة.")
                return

        if not user_id:
            send_pretty_message(chat_id, "لم يتم تحديد المستخدم بشكل صحيح.")
            return

        target_member = bot.get_chat_member(chat_id, user_id)

        if target_member.status in ["administrator", "creator"]:
            send_pretty_message(chat_id, "🚫 لا يمكن إلغاء كتم مشرف أو مالك المجموعة!")
            return

        # التحقق من حالة الكتم (بعض الحسابات ما يظهر فيها can_send_messages فنستخدم try)
        if hasattr(target_member, 'can_send_messages') and target_member.can_send_messages:
            send_pretty_message(chat_id, f"🚫 المستخدم <a href='tg://user?id={user_id}'>هذا</a> ليس مكتومًا بالفعل.")
            return

        permissions = types.ChatPermissions(
            can_send_messages=True,
            can_send_media_messages=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True
        )
        bot.restrict_chat_member(chat_id, user_id, permissions=permissions)

        name_or_link = f"@{target_username}" if target_username else f"<a href='tg://user?id={user_id}'>المستخدم</a>"
        send_pretty_message(chat_id, f'🙂 تم إلغاء الكتم عن {name_or_link}.')

    except Exception as e:
        print("خطأ في أمر إلغاء الكتم:", e)
        traceback.print_exc()
        send_pretty_message(message.chat.id, f"في مشكلة: {e}\nحاول مرة تانية.")

import time
import traceback
from telebot import types

# تأكد من تعريف المتغيرات التالية مسبقاً: bot, promotion_data, is_user_admin, is_bot_admin, send_pretty_message, edit_pretty_message

def safe_edit_message(chat_id, message_id, text, reply_markup=None):
    try:
        bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup=reply_markup, parse_mode="HTML")
    except Exception as e:
        print("تعذر تعديل الرسالة، إرسال رسالة جديدة بدلاً منها:", e)
        bot.send_message(chat_id, text, reply_markup=reply_markup, parse_mode="HTML")


# القائمة الافتراضية للصلاحيات المتاحة في تيليجرام للمشرفين
default_permissions = {
    "change_info": False,
    "delete": False,
    "invite": False,
    "restrict": False,
    "pin": False,
    "manage_chat": False,
    "manage_voice": False
}

# ترجمة أسماء الصلاحيات للعربية
permissions_labels = {
    "change_info": "تغيير معلومات المجموعة",
    "delete": "حذف الرسائل",
    "invite": "دعوة الأعضاء",
    "restrict": "تقييد الأعضاء",
    "pin": "تثبيت الرسائل",
    "manage_chat": "إدارة المجموعة",
    "manage_voice": "إدارة الصوت"
}


@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("رفع"))
def promote_user(message):
    try:
        chat_id = message.chat.id
        if message.chat.type not in ["supergroup", "group"]:
            return

        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return

        if not message.reply_to_message and '@' not in message.text:
            send_pretty_message(chat_id, "يجب الرد على رسالة المستخدم أو ذكر المعرف @ لرفعه مشرف.")
            return

        if not is_bot_admin(chat_id):
            send_pretty_message(chat_id, "البوت ليس مسؤولاً.")
            return

        issuer = bot.get_chat_member(chat_id, message.from_user.id)
        if issuer.status != "creator" and not issuer.can_promote_members:
            send_pretty_message(chat_id, "فقط المالك أو من لديه صلاحية رفع المشرفين يمكنه رفع مشرف.")
            return

        # تحديد المستخدم الهدف
        target_id = None
        target_username = None

        if message.reply_to_message:
            target_id = message.reply_to_message.from_user.id
        elif '@' in message.text:
            target_username = message.text.split('@')[1].split()[0].lower()
            if not target_username:
                send_pretty_message(chat_id, "يجب ذكر معرف صحيح بعد @.")
                return

            # نحاول البحث عن العضو بالمعرف بين الأعضاء الحاليين
            try:
                members = bot.get_chat_administrators(chat_id)
                for admin in members:
                    if admin.user.username and admin.user.username.lower() == target_username:
                        target_id = admin.user.id
                        break

                if not target_id:
                    # إذا لم يكن من ضمن الأدمنية، نحاول نحصل عليه عادي
                    target_member = bot.get_chat_member(chat_id, target_username)
                    target_id = target_member.user.id
            except Exception:
                send_pretty_message(chat_id, f"لا يمكن العثور على @{target_username} في المجموعة.")
                return
        else:
            send_pretty_message(chat_id, "يجب الرد على رسالة المستخدم أو ذكر المعرف @ لرفعه مشرف.")
            return

        key = f"{chat_id}_{target_id}"
        promotion_data[key] = default_permissions.copy()

        markup = types.InlineKeyboardMarkup()
        btn_all = types.InlineKeyboardButton("كل الصلاحيات", callback_data=f"promote_all|{chat_id}|{target_id}|{message.from_user.id}")
        btn_custom = types.InlineKeyboardButton("اختيار صلاحيات بنفسي", callback_data=f"promote_custom|{chat_id}|{target_id}|{message.from_user.id}")
        markup.add(btn_all)
        markup.add(btn_custom)

        safe_edit_message(chat_id, message.message_id, "✨ اختر صلاحيات المشرف المطلوبة:", reply_markup=markup)

    except Exception as e:
        print("خطأ في أمر رفع المشرف:", e)
        traceback.print_exc()
        send_pretty_message(message.chat.id, f"في مشكلة: {e}\nحاول مرة تانية.")


@bot.callback_query_handler(func=lambda call: call.data.startswith("promote_all|"))
def handle_promote_all(call):
    try:
        parts = call.data.split("|")
        # parts[0] = "promote_all"
        chat_id = int(parts[1])
        target_id = int(parts[2])
        issuer_id = int(parts[3])

        if call.from_user.id != issuer_id:
            bot.answer_callback_query(call.id, "ليس لديك صلاحية تنفيذ هذا الأمر.")
            return

        bot.promote_chat_member(
            chat_id,
            target_id,
            can_change_info=True,
            can_delete_messages=True,
            can_invite_users=True,
            can_restrict_members=True,
            can_pin_messages=True,
            can_promote_members=False,  # لا يتم منح صلاحية رفع مشرفين
            can_manage_chat=True,
            can_manage_voice_chats=True
        )
        bot.answer_callback_query(call.id, "تم رفع المستخدم بكل الصلاحيات.")
        safe_edit_message(chat_id, call.message.message_id, "تم رفع المستخدم بكل الصلاحيات.")
    except Exception as e:
        print("خطأ في معالج زر رفع كل الصلاحيات:", e)
        traceback.print_exc()
        bot.answer_callback_query(call.id, f"في مشكلة: {e}")


@bot.callback_query_handler(func=lambda call: call.data.startswith("promote_custom|"))
def handle_promote_custom(call):
    try:
        parts = call.data.split("|")
        # parts[0] = "promote_custom"
        chat_id = int(parts[1])
        target_id = int(parts[2])
        issuer_id = int(parts[3])

        if call.from_user.id != issuer_id:
            bot.answer_callback_query(call.id, "يحرام انت مش مشرف له له له 💔😂")
            return

        key = f"{chat_id}_{target_id}"
        if key not in promotion_data:
            promotion_data[key] = default_permissions.copy()

        current = promotion_data[key]
        markup = types.InlineKeyboardMarkup()
        # عرض أزرار الصلاحيات المتاحة مع أسماء عربية
        for perm in ["change_info", "delete", "invite", "restrict", "pin", "manage_chat", "manage_voice"]:
            status = "✅" if current.get(perm) else "❌"
            label = permissions_labels.get(perm, perm)
            btn = types.InlineKeyboardButton(f"{label} {status}", callback_data=f"toggle|{perm}|{chat_id}|{target_id}|{issuer_id}")
            markup.add(btn)
        # زر التأكيد النهائي
        markup.add(types.InlineKeyboardButton("تأكيد الترقية", callback_data=f"confirm_promote|{chat_id}|{target_id}|{issuer_id}"))
        # زر الإلغاء
        markup.add(types.InlineKeyboardButton("إلغاء", callback_data=f"cancel_promotion|{chat_id}|{target_id}|{issuer_id}"))

        safe_edit_message(chat_id, call.message.message_id, "✨ اختر صلاحيات المشرف المطلوبة:", reply_markup=markup)
        bot.answer_callback_query(call.id)
    except Exception as e:
        print("خطأ في معالج الترقية المخصصة:", e)
        traceback.print_exc()
        bot.answer_callback_query(call.id, f"في مشكلة: {e}")


@bot.callback_query_handler(func=lambda call: call.data.startswith("toggle|"))
def toggle_permission(call):
    try:
        parts = call.data.split("|")
        # parts[0] = "toggle"
        perm = parts[1]
        chat_id = int(parts[2])
        target_id = int(parts[3])
        issuer_id = int(parts[4])

        if call.from_user.id != issuer_id:
            bot.answer_callback_query(call.id, "ليس لديك صلاحية تغيير هذه الإعدادات.")
            return

        key = f"{chat_id}_{target_id}"
        if key not in promotion_data:
            promotion_data[key] = default_permissions.copy()

        current = promotion_data[key]
        current[perm] = not current[perm]

        markup = types.InlineKeyboardMarkup()
        for p in ["change_info", "delete", "invite", "restrict", "pin", "manage_chat", "manage_voice"]:
            status = "✅" if current.get(p) else "❌"
            label = permissions_labels.get(p, p)
            btn = types.InlineKeyboardButton(f"{label} {status}", callback_data=f"toggle|{p}|{chat_id}|{target_id}|{issuer_id}")
            markup.add(btn)
        markup.add(types.InlineKeyboardButton("تأكيد الترقية", callback_data=f"confirm_promote|{chat_id}|{target_id}|{issuer_id}"))
        markup.add(types.InlineKeyboardButton("إلغاء", callback_data=f"cancel_promotion|{chat_id}|{target_id}|{issuer_id}"))

        safe_edit_message(chat_id, call.message.message_id, "✨ اختر صلاحيات المشرف المطلوبة:", reply_markup=markup)
        bot.answer_callback_query(call.id)
    except Exception as e:
        print("خطأ في معالج تغيير الصلاحية:", e)
        traceback.print_exc()
        bot.answer_callback_query(call.id, f"في مشكلة: {e}")


@bot.callback_query_handler(func=lambda call: call.data.startswith("confirm_promote|"))
def confirm_promote(call):
    try:
        parts = call.data.split("|")
        # parts[0] = "confirm_promote"
        chat_id = int(parts[1])
        target_id = int(parts[2])
        issuer_id = int(parts[3])

        if call.from_user.id != issuer_id:
            bot.answer_callback_query(call.id, "ليس لديك صلاحية تنفيذ هذا الأمر.")
            return

        key = f"{chat_id}_{target_id}"
        if key not in promotion_data:
            bot.answer_callback_query(call.id, "لم يتم تحديد صلاحيات.")
            return

        current = promotion_data[key]
        bot.promote_chat_member(
            chat_id,
            target_id,
            can_change_info=current["change_info"],
            can_delete_messages=current["delete"],
            can_invite_users=current["invite"],
            can_restrict_members=current["restrict"],
            can_pin_messages=current["pin"],
            can_promote_members=False,
            can_manage_chat=current["manage_chat"],
            can_manage_voice_chats=current["manage_voice"]
        )

        bot.answer_callback_query(call.id, "تم رفع المستخدم مع الصلاحيات المحددة.")
        safe_edit_message(chat_id, call.message.message_id, "تم رفع المستخدم مع الصلاحيات المحددة.")
    except Exception as e:
        print("خطأ في معالج تأكيد الترقية:", e)
        traceback.print_exc()
        bot.answer_callback_query(call.id, f"في مشكلة: {e}")


@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("تنزيل"))
def demote_user(message):
    try:
        chat_id = message.chat.id
        if message.chat.type not in ["supergroup", "group"]:
            return

        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "ليس لديك صلاحيات كافية.")
            return

        if not is_bot_admin(chat_id):
            send_pretty_message(chat_id, "البوت ليس مسؤولاً.")
            return

        # التحقق من صلاحيات من نفذ الأمر
        issuer = bot.get_chat_member(chat_id, message.from_user.id)
        if issuer.status != "creator" and not issuer.can_promote_members:
            send_pretty_message(chat_id, "فقط المالك أو من لديه صلاحية رفع المشرفين يمكنه تنزيل مشرف.")
            return

        # استخراج الهدف
        target_id = None
        target_username = None

        if message.reply_to_message:
            target_id = message.reply_to_message.from_user.id

        elif '@' in message.text:
            target_username = message.text.split('@')[1].split()[0].lower()
            if not target_username:
                send_pretty_message(chat_id, "يرجى تحديد معرف صحيح بعد @.")
                return

            # نحاول البحث عن المستخدم من ضمن الأدمنية الحاليين
            admins = bot.get_chat_administrators(chat_id)
            for admin in admins:
                if admin.user.username and admin.user.username.lower() == target_username:
                    target_id = admin.user.id
                    break

            if not target_id:
                send_pretty_message(chat_id, f"لم يتم العثور على @{target_username} بين المشرفين في المجموعة.")
                return

        else:
            send_pretty_message(chat_id, "يجب الرد على رسالة المستخدم أو ذكر المعرف @ لتنزيله.")
            return

        target_member = bot.get_chat_member(chat_id, target_id)

        if target_member.status == "creator":
            send_pretty_message(chat_id, "🚫 لا يمكن تنزيل المالك!")
            return

        if target_member.user.is_bot:
            send_pretty_message(chat_id, "🚫 لا يمكن تنزيل البوت!")
            return

        if target_member.status != "administrator":
            send_pretty_message(chat_id, "المستخدم غير ادمن أصلاً.")
            return

        # تنفيذ التنزيل
        bot.promote_chat_member(
            chat_id,
            target_id,
            can_change_info=False,
            can_delete_messages=False,
            can_invite_users=False,
            can_restrict_members=False,
            can_pin_messages=False,
            can_promote_members=False
        )

        name_or_username = f"@{target_member.user.username}" if target_member.user.username else f"<a href='tg://user?id={target_id}'>المستخدم</a>"
        send_pretty_message(chat_id, f"تم تنزيل {name_or_username} من الإشراف.")

    except Exception as e:
        print("خطأ في أمر تنزيل المشرف:", e)
        traceback.print_exc()
        send_pretty_message(message.chat.id, f"في مشكلة: {e}\nحاول مرة تانية.")

@bot.message_handler(func=lambda message: message.text and message.text.lower() in ["كشف", "الاوامر"])
def hala_command(message):
    try:
        chat_id = message.chat.id

        if message.reply_to_message and message.text.lower() == "كشف":
            target = message.reply_to_message.from_user
            user_info = "👤 <b>معلومات المستخدم</b> :\n"
            user_info += f"🆔 <b>المعرف :</b> {target.id}\n"
            user_info += f"📛 <b>الاسم :</b> {target.first_name}"
            if hasattr(target, 'last_name') and target.last_name:
                user_info += f" {target.last_name}"
            if hasattr(target, 'username') and target.username:
                user_info += f"\n🔰 <b>اليوزر :</b> @{target.username}"

            is_admin = is_user_admin(chat_id, message.from_user.id)

            markup = types.InlineKeyboardMarkup()
            if is_admin:
                btn_admin = types.InlineKeyboardButton(
                    "⚙️ خيارات الادارة",
                    callback_data=f"admin_options_{chat_id}_{target.id}_{message.from_user.id}"
                )
                markup.add(btn_admin)

            photos = bot.get_user_profile_photos(target.id)
            if photos.total_count > 0:
                file_id = photos.photos[0][0].file_id
                bot.send_photo(chat_id, file_id, caption=user_info, reply_markup=markup if is_admin else None, parse_mode="HTML")
            else:
                send_pretty_message(chat_id, user_info, reply_markup=markup if is_admin else None)

        elif message.text.lower() == "الاوامر":
            text = """
● اوامر المالك/المشرفين
● (الرد على الرسالة او @)
● رفع - رفع مشرف
● تنزيل - تنزيل مشرف
● تشمل ايضا اوامر المشرفين
● كشف - معلومات المستخدم
● اعلان - رسالة للمشرفين
● مسح - عدد [الرسائل]
● الاعدادات - إعدادات المجموعة
● الاحصائيات - إحصائيات المجموعة
● قفل/فتح - روابط صور...
● حظر
● كتم
● تثبيت
● تحذير
● القوانين
● صلاحيات
● تعيين الترحيب
● الغاء التثبيت
● الغاء الحظر
● الغاء الكتم
● التحذيرات
● حذف التحذيرات
● تعيين القوانين
○ اوامر التسليه
○ ميم - ميم عشوائي
○ كرة - الرد عشوائي
○ عكس - عكس النص
○ وظيفة البرمجة – /vip
"""
            bot.send_message(chat_id, text, parse_mode="HTML")

    except Exception as e:
        print("خطأ في أمر hala:", e)
        traceback.print_exc()
        send_pretty_message(message.chat.id, f"في مشكلة: {e}\nحاول مرة تانية.")

############################################
# معالجات الأزرار للتفاعل في واجهة الإدارة
############################################

@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_options_"))
def admin_options(call):
    try:
        # بيانات الزر: "admin_options_{chat_id}_{target_id}_{initiator_id}"
        parts = call.data.split("_")
        chat_id = int(parts[2])
        target_id = int(parts[3])
        initiator_id = int(parts[4])
        if call.from_user.id != initiator_id:
            bot.answer_callback_query(call.id, "يحرام انت مش مشرف له له له 💔😂")
            return
        markup = types.InlineKeyboardMarkup()
        btn_mute = types.InlineKeyboardButton("🤐 كتم", callback_data=f"action_mute_{chat_id}_{target_id}_{initiator_id}")
        btn_unmute = types.InlineKeyboardButton("🙂 إلغاء كتم", callback_data=f"action_unmute_{chat_id}_{target_id}_{initiator_id}")
        btn_ban = types.InlineKeyboardButton("🚫 حظر", callback_data=f"action_ban_{chat_id}_{target_id}_{initiator_id}")
        btn_unban = types.InlineKeyboardButton("إلغاء حظر", callback_data=f"action_unban_{chat_id}_{target_id}_{initiator_id}")
        btn_back = types.InlineKeyboardButton("🔙 رجوع", callback_data=f"back_to_info_{chat_id}_{target_id}_{initiator_id}")
        markup.row(btn_mute, btn_unmute)
        markup.row(btn_ban, btn_unban)
        markup.add(btn_back)
        edit_pretty_message(chat_id, call.message.message_id, "⚙️ اختر إجراء من إجراءات الادارة:", reply_markup=markup)
        bot.answer_callback_query(call.id)
    except Exception as e:
        print("خطأ في خيارات الادارة:", e)
        traceback.print_exc()
        bot.answer_callback_query(call.id, f"في مشكلة: {e}\nحاول مرة تانية.")

@bot.callback_query_handler(func=lambda call: call.data.startswith("action_"))
def admin_actions(call):
    try:
        # مثال: "action_mute_{chat_id}_{target_id}_{initiator_id}"
        parts = call.data.split("_")
        action = parts[1]
        chat_id = int(parts[2])
        target_id = int(parts[3])
        initiator_id = int(parts[4])
        if call.from_user.id != initiator_id:
            bot.answer_callback_query(call.id, "يحرام انت مش مشرف له له له 💔😂")
            return
        if not is_bot_admin(chat_id):
            bot.answer_callback_query(call.id, "البوت ليس مسؤولاً.")
            return
        result_text = ""
        if action == "mute":
            permissions = types.ChatPermissions(can_send_messages=False)
            bot.restrict_chat_member(chat_id, target_id, permissions=permissions)
            result_text = f"🤐 المستخدم {target_id} تم كتمه."
        elif action == "unmute":
            permissions = types.ChatPermissions(
                can_send_messages=True,
                can_send_media_messages=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True
            )
            bot.restrict_chat_member(chat_id, target_id, permissions=permissions)
            result_text = f"🙂 المستخدم {target_id} تم إلغاء الكتم."
        elif action == "ban":
            bot.ban_chat_member(chat_id, target_id)
            result_text = f"🚫 المستخدم {target_id} تم حظره."
        elif action == "unban":
            bot.unban_chat_member(chat_id, target_id)
            result_text = f"المستخدم {target_id} تم إلغاء الحظر."
        markup = types.InlineKeyboardMarkup()
        btn_back = types.InlineKeyboardButton("🔙 رجوع", callback_data=f"back_to_info_{chat_id}_{target_id}_{initiator_id}")
        markup.add(btn_back)
        edit_pretty_message(chat_id, call.message.message_id, result_text, reply_markup=markup)
        bot.answer_callback_query(call.id)
    except Exception as e:
        print("خطأ في تنفيذ الإجراء:", e)
        traceback.print_exc()
        bot.answer_callback_query(call.id, f"في مشكلة: {e}\nحاول مرة تانية.")

@bot.callback_query_handler(func=lambda call: call.data.startswith("back_to_info_"))
def back_to_info(call):
    try:
        # بيانات الزر: "back_to_info_{chat_id}_{target_id}_{initiator_id}"
        parts = call.data.split("_")
        chat_id = int(parts[3])
        target_id = int(parts[4])
        initiator_id = int(parts[5])
        if call.from_user.id != initiator_id:
            bot.answer_callback_query(call.id, "يحرام انت مش مشرف له له له 💔😂")
            return
        user = bot.get_chat_member(chat_id, target_id).user
        user_info = "👤 <b>معلومات المستخدم</b>:\n"
        user_info += f"🆔 <b>المعرف:</b> {user.id}\n"
        user_info += f"📛 <b>الاسم:</b> {user.first_name}"
        if hasattr(user, 'last_name') and user.last_name:
            user_info += f" {user.last_name}"
        if hasattr(user, 'username') and user.username:
            user_info += f"\n🔰 <b>اليوزر:</b> @{user.username}"
        markup = types.InlineKeyboardMarkup()
        btn_admin = types.InlineKeyboardButton("⚙️ خيارات الادارة", callback_data=f"admin_options_{chat_id}_{target_id}_{initiator_id}")
        markup.add(btn_admin)
        edit_pretty_message(chat_id, call.message.message_id, user_info, reply_markup=markup)
        bot.answer_callback_query(call.id)
    except Exception as e:
        print("خطأ بالرجوع للمعلومات:", e)
        traceback.print_exc()
        bot.answer_callback_query(call.id, f"في مشكلة: {e}\nحاول مرة تانية.")

############################################
# أوامر إضافية للإدارة والتفاعل
############################################

# /warn - إرسال تحذير للمستخدم (تزداد التحذيرات مع كل طلب)
@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("تحذير"))
def warn_user(message):
    try:
        chat_id = message.chat.id
        if message.chat.type not in ["supergroup", "group"]:
            return

        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return

        user_id = None
        target_username = None

        if message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
        elif '@' in message.text:
            target_username = message.text.split('@')[1].split()[0].lower()
            if not target_username:
                send_pretty_message(chat_id, "يرجى تحديد معرف صحيح بعد @.")
                return
            try:
                # نحاول البحث بين المشرفين أولاً
                admins = bot.get_chat_administrators(chat_id)
                for admin in admins:
                    if admin.user.username and admin.user.username.lower() == target_username:
                        user_id = admin.user.id
                        break

                if not user_id:
                    member = bot.get_chat_member(chat_id, target_username)
                    user_id = member.user.id
            except Exception:
                send_pretty_message(chat_id, f"لا يمكن العثور على @{target_username} في المجموعة.")
                return
        else:
            send_pretty_message(chat_id, "يجب الرد على المستخدم أو استخدام @ لتحذيره.")
            return

        chat_member = bot.get_chat_member(chat_id, user_id)

        if chat_member.status in ["administrator", "creator"]:
            send_pretty_message(chat_id, "🚫 لا يمكن تحذير مشرف أو مالك المجموعة!")
            return

        key = f"{chat_id}_{user_id}"
        warnings_data[key] = warnings_data.get(key, 0) + 1
        display_name = f"@{target_username}" if target_username else f"<a href='tg://user?id={user_id}'>المستخدم</a>"
        send_pretty_message(chat_id, f"⚠️ تم تحذير {display_name}. التحذيرات الحالية: {warnings_data[key]}")
    except Exception as e:
        print("خطأ في أمر التحذير:", e)
        traceback.print_exc()
        send_pretty_message(message.chat.id, f"في مشكلة: {e}\nحاول مرة تانية.")

# /warnings - عرض عدد التحذيرات للمستخدم
@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("التحذيرات"))
def show_warnings(message):
    try:
        chat_id = message.chat.id
        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return

        user_id = None
        username = None

        if message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
        elif '@' in message.text:
            username = message.text.split('@')[1].split()[0].lower()
            try:
                member = bot.get_chat_member(chat_id, username)
                user_id = member.user.id
            except Exception:
                send_pretty_message(chat_id, f"لا يمكن العثور على @{username} في المجموعة.")
                return
        else:
            send_pretty_message(chat_id, "يجب الرد على رسالة المستخدم أو ذكره باستخدام @ لعرض تحذيراته.")
            return

        key = f"{chat_id}_{user_id}"
        count = warnings_data.get(key, 0)
        send_pretty_message(chat_id, f"⚠️ لدى المستخدم <a href='tg://user?id={user_id}'>{user_id}</a> {count} تحذير(ات).")
    except Exception as e:
        print("خطأ في عرض التحذيرات:", e)
        traceback.print_exc()
        send_pretty_message(message.chat.id, f"في مشكلة: {e}\nحاول مرة تانية.")

# /resetwarns - تصفير التحذيرات لمستخدم معين
@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("حذف التحذيرات"))
def reset_warnings(message):
    try:
        chat_id = message.chat.id
        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return

        user_id = None
        username = None

        if message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
        elif '@' in message.text:
            username = message.text.split('@')[1].split()[0].lower()
            try:
                member = bot.get_chat_member(chat_id, username)
                user_id = member.user.id
            except Exception:
                send_pretty_message(chat_id, f"لا يمكن العثور على @{username} في المجموعة.")
                return
        else:
            send_pretty_message(chat_id, "يجب الرد على رسالة المستخدم أو ذكره باستخدام @ لتصفير تحذيراته.")
            return

        key = f"{chat_id}_{user_id}"
        warnings_data[key] = 0
        send_pretty_message(chat_id, f"✅ تم تصفير التحذيرات للمستخدم <a href='tg://user?id={user_id}'>{user_id}</a>.")
    except Exception as e:
        print("خطأ في أمر تصفير التحذيرات:", e)
        traceback.print_exc()
        send_pretty_message(message.chat.id, f"في مشكلة: {e}\nحاول مرة تانية.")

# /setwelcome - تعيين رسالة ترحيب للمجموعة (يجب أن يكون الرد على رسالة نصية)
WELCOME_FILE = "welcome_messages.json"

def load_welcome_messages():
    if os.path.exists(WELCOME_FILE):
        with open(WELCOME_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_welcome_messages(data):
    with open(WELCOME_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

welcome_messages = load_welcome_messages()

# متغير لتخزين بيانات الترحيب داخل الذاكرة (يمكن استخدامه للتعامل مع التعديلات أثناء تشغيل البوت)
welcome_messages = {}

# المجلد الرئيسي الذي سيحتوي على مجلدات كل مجموعة
BASE_DIR = "groups_welcome"

# دالة لحفظ رسالة الترحيب في ملف JSON داخل مجلد المجموعة الخاصة
def save_welcome_messages(chat_id, data):
    # التأكد من وجود المجلد الرئيسي
    if not os.path.exists(BASE_DIR):
        os.mkdir(BASE_DIR)
    # إنشاء مجلد للمجموعة باستخدام chat_id (كنظام تسمية فريد)
    group_dir = os.path.join(BASE_DIR, str(chat_id))
    if not os.path.exists(group_dir):
        os.mkdir(group_dir)
    # مسار الملف داخل المجلد الخاص بالمجموعة
    file_path = os.path.join(group_dir, "welcome.json")
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# دالة لتحميل رسالة الترحيب من ملف JSON (اختياري، يمكن استخدامها أثناء بدء تشغيل البوت لتحميل البيانات)
def load_welcome_message(chat_id):
    group_dir = os.path.join(BASE_DIR, str(chat_id))
    file_path = os.path.join(group_dir, "welcome.json")
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return None

# دالة لتحويل الكيانات (entities) إلى تنسيق HTML بحيث يتم الاحتفاظ بالتنسيقات مثل الخط العريض والمائل والاقتباس
def convert_entities_to_html(reply_message):
    """
    تقوم هذه الدالة بتحويل النص أو التسمية التوضيحية (caption) مع الكيانات إلى HTML.
    تدعم الدالة تنسيقات مثل bold, italic, underline, code, pre, text_link, blockquote.
    """
    if hasattr(reply_message, "text") and reply_message.text:
        text = reply_message.text
        entities = reply_message.entities
    else:
        text = reply_message.caption if hasattr(reply_message, "caption") else ""
        entities = reply_message.caption_entities

    if not entities:
        return text

    formatted_text = ""
    last_index = 0
    for entity in entities:
        start = entity.offset
        end = entity.offset + entity.length
        formatted_text += text[last_index:start]
        entity_text = text[start:end]
        if entity.type == "bold":
            formatted_text += f"<b>{entity_text}</b>"
        elif entity.type == "italic":
            formatted_text += f"<i>{entity_text}</i>"
        elif entity.type == "underline":
            formatted_text += f"<u>{entity_text}</u>"
        elif entity.type == "code":
            formatted_text += f"<code>{entity_text}</code>"
        elif entity.type == "pre":
            formatted_text += f"<pre>{entity_text}</pre>"
        elif entity.type == "text_link" and hasattr(entity, "url"):
            formatted_text += f'<a href="{entity.url}">{entity_text}</a>'
        elif entity.type == "blockquote":
            formatted_text += f"<blockquote>{entity_text}</blockquote>"
        else:
            formatted_text += entity_text
        last_index = end
    formatted_text += text[last_index:]
    return formatted_text

# تعيين رسالة الترحيب عند الرد على رسالة تحتوي على الترحيب (النص والمرفق إن وُجد)
@bot.message_handler(func=lambda message: message.text and message.text.lower() == "تعيين الترحيب")
def set_welcome(message):
    try:
        chat_id = str(message.chat.id)

        # التحقق من صلاحيات المشرف
        if not is_user_admin(message.chat.id, message.from_user.id):
            bot.send_message(message.chat.id, "يحرام انت مش مشرف له له له 💔😂")
            return

        # التأكد من الرد على رسالة تحتوي على محتوى الترحيب
        if not message.reply_to_message:
            bot.send_message(message.chat.id, "رد على رسالة الترحيب حبيبي")
            return

        welcome_data = {}

        # إذا كانت الرسالة تحتوي على نص أو caption يتم تحويله إلى HTML مع التنسيقات
        if (hasattr(message.reply_to_message, "text") and message.reply_to_message.text) or \
           (hasattr(message.reply_to_message, "caption") and message.reply_to_message.caption):
            welcome_text = convert_entities_to_html(message.reply_to_message)
            welcome_data["text"] = welcome_text

        # جمع المرفقات الموجودة في رسالة الترحيب (إذا وُجد)
        media = []
        if message.reply_to_message.photo:
            # اختيار آخر صورة لضمان الجودة الأفضل
            photo_id = message.reply_to_message.photo[-1].file_id
            media.append({"type": "photo", "file_id": photo_id})
        if message.reply_to_message.video:
            video_file_id = message.reply_to_message.video.file_id
            media.append({"type": "video", "file_id": video_file_id})
        if message.reply_to_message.animation:
            anim_file_id = message.reply_to_message.animation.file_id
            media.append({"type": "animation", "file_id": anim_file_id})
        if message.reply_to_message.document:
            doc_file_id = message.reply_to_message.document.file_id
            media.append({"type": "document", "file_id": doc_file_id})

        if media:
            welcome_data["media"] = media

        # تخزين بيانات الترحيب في الذاكرة وفي ملف JSON داخل مجلد المجموعة
        welcome_messages[chat_id] = welcome_data
        save_welcome_messages(chat_id, welcome_data)

        bot.send_message(message.chat.id, "تم حفظ رسالة الترحيب")
    except Exception as e:
        print("خطأ في أمر الترحيب:", e)
        traceback.print_exc()

# دالة لفحص صلاحيات المسؤول في المجموعة
def is_user_admin(chat_id, user_id):
    try:
        chat_admins = bot.get_chat_administrators(chat_id)
        for admin in chat_admins:
            if admin.user.id == user_id:
                return True
    except Exception as e:
        print("خطأ في التحقق من صلاحيات المشرف:", e)
    return False

# استقبال حدث انضمام الأعضاء الجدد وإرسال الترحيب بالطريقة التي تم تعيينها
@bot.message_handler(content_types=["new_chat_members"])
def welcome_new_member(message):
    chat_id = str(message.chat.id)
    if chat_id not in welcome_messages:
        return

    data = welcome_messages[chat_id]
    text_template = data.get("text", "")
    media_items = data.get("media", [])

    # اسم أو معرف المستخدم الجديد
    for new_member in message.new_chat_members:
        mention = f"@{new_member.username}" if new_member.username else new_member.first_name
        text = text_template.replace("{username}", mention)

        # حالة وجود نص مع مرفق واحد: يتم إرسال المرفق مع caption
        if len(media_items) == 1 and text:
            item = media_items[0]
            if item["type"] == "photo":
                bot.send_photo(message.chat.id, item["file_id"], caption=text, parse_mode="HTML")
            elif item["type"] == "video":
                bot.send_video(message.chat.id, item["file_id"], caption=text, parse_mode="HTML")
            elif item["type"] == "animation":
                bot.send_animation(message.chat.id, item["file_id"], caption=text, parse_mode="HTML")
            elif item["type"] == "document":
                try:
                    bot.send_document(message.chat.id, item["file_id"], caption=text, parse_mode="HTML")
                except Exception:
                    bot.send_document(message.chat.id, item["file_id"])
                    bot.send_message(message.chat.id, text, parse_mode="HTML")
        else:
            if text:
                bot.send_message(message.chat.id, text, parse_mode="HTML")
            if media_items:
                if len(media_items) > 1:
                    media_group = []
                    for item in media_items:
                        if item["type"] == "photo":
                            media_group.append(types.InputMediaPhoto(item["file_id"]))
                        elif item["type"] == "video":
                            media_group.append(types.InputMediaVideo(item["file_id"]))
                        elif item["type"] == "animation":
                            media_group.append(types.InputMediaAnimation(item["file_id"]))
                        elif item["type"] == "document":
                            media_group.append(types.InputMediaDocument(item["file_id"]))
                    bot.send_media_group(message.chat.id, media_group)
                else:
                    item = media_items[0]
                    if item["type"] == "photo":
                        bot.send_photo(message.chat.id, item["file_id"])
                    elif item["type"] == "video":
                        bot.send_video(message.chat.id, item["file_id"])
                    elif item["type"] == "animation":
                        bot.send_animation(message.chat.id, item["file_id"])
                    elif item["type"] == "document":
                        bot.send_document(message.chat.id, item["file_id"])

BASE_DIR = "groups_data"

def save_group_rules(chat_id, rules_data):
    group_dir = os.path.join(BASE_DIR, str(chat_id))
    os.makedirs(group_dir, exist_ok=True)
    file_path = os.path.join(group_dir, "rules.json")
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(rules_data, f, ensure_ascii=False, indent=4)

def load_group_rules(chat_id):
    file_path = os.path.join(BASE_DIR, str(chat_id), "rules.json")
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return None

def convert_entities_to_html(message):
    if hasattr(message, "text") and message.text:
        text = message.text
        entities = message.entities
    else:
        return ""

    if not entities:
        return text

    formatted = ""
    last = 0
    for entity in entities:
        start, end = entity.offset, entity.offset + entity.length
        formatted += text[last:start]
        entity_text = text[start:end]
        if entity.type == "bold":
            formatted += f"<b>{entity_text}</b>"
        elif entity.type == "italic":
            formatted += f"<i>{entity_text}</i>"
        elif entity.type == "underline":
            formatted += f"<u>{entity_text}</u>"
        elif entity.type == "code":
            formatted += f"<code>{entity_text}</code>"
        elif entity.type == "pre":
            formatted += f"<pre>{entity_text}</pre>"
        elif entity.type == "text_link" and hasattr(entity, "url"):
            formatted += f'<a href="{entity.url}">{entity_text}</a>'
        else:
            formatted += entity_text
        last = end
    formatted += text[last:]
    return formatted

# تعيين القوانين
@bot.message_handler(func=lambda message: message.text and message.text.lower() == "تعيين القوانين")
def set_rules(message):
    try:
        chat_id = str(message.chat.id)
        if not is_user_admin(int(chat_id), message.from_user.id):
            send_pretty_message(message.chat.id, "يحرام انت مش مشرف له له له 💔😂")
            return

        if not message.reply_to_message or not message.reply_to_message.text:
            send_pretty_message(message.chat.id, "يجب الرد على رسالة تحتوي على قوانين المجموعة.")
            return

        rules_html = convert_entities_to_html(message.reply_to_message)
        save_group_rules(chat_id, {"text": rules_html})

        send_pretty_message(message.chat.id, "تم تعيين قوانين المجموعة.")
    except Exception as e:
        print("خطأ في أمر تعيين القوانين:", e)
        traceback.print_exc()

# عرض القوانين
@bot.message_handler(func=lambda message: message.text and message.text.lower() == "القوانين")
def show_rules(message):
    try:
        chat_id = str(message.chat.id)
        rules_data = load_group_rules(chat_id)
        if not rules_data:
            send_pretty_message(chat_id, "لم يتم تعيين قوانين للمجموعة.")
            return

        rules_text = rules_data["text"]
        user_mention = f"@{message.from_user.username}" if message.from_user.username else message.from_user.first_name
        rules_text = rules_text.replace("{username}", user_mention)

        send_pretty_message(chat_id, f"\n{rules_text}", parse_mode="HTML")
    except Exception as e:
        print("خطأ في أمر عرض القوانين:", e)
        traceback.print_exc()

BASE_DIR = "groups_data"

def get_group_dir(chat_id):
    group_dir = os.path.join(BASE_DIR, str(chat_id))
    os.makedirs(group_dir, exist_ok=True)
    return group_dir

def save_group_json(chat_id, filename, data):
    path = os.path.join(get_group_dir(chat_id), filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def load_group_json(chat_id, filename):
    path = os.path.join(get_group_dir(chat_id), filename)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

# حذف تلقائي بكلمة "حذف تلقائي"
@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("حذف تلقائي"))
def auto_delete(message):
    try:
        chat_id = str(message.chat.id)
        if not is_user_admin(int(chat_id), message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return

        try:
            seconds = int(message.text.split()[2])  # حذف تلقائي 10
        except:
            send_pretty_message(chat_id, "يرجى تحديد عدد الثواني بشكل صحيح.\nمثال: حذف تلقائي 10")
            return

        save_group_json(chat_id, "auto_delete.json", {"seconds": seconds})
        send_pretty_message(chat_id, f"سيتم حذف الرسائل تلقائيًا بعد {seconds} ثانية.")
    except Exception as e:
        print("خطأ في أمر حذف تلقائي:", e)
        traceback.print_exc()

# الأنواع المدعومة بالإنجليزي مع وصفها
SUPPORTED_MEDIA_TYPES = {
    "photo": "الصور",
    "video": "الفيديو",
    "document": "الملفات",
    "audio": "الملفات الصوتيه",
    "voice": "الصوت",
    "sticker": "الملصقات",
    "animation": "الصور المتحركه",
}

# تحويل الكلمات بالعربي إلى أنواع إنجليزية
ARABIC_MEDIA_TYPES = {
    "الصور": "photo",
    "الفيديو": "video",
    "الملفات": "document",
    "ملف": "document",
    "الملفات الصوتيه": "audio",
    "الصوت": "voice",
    "الملصقات": "sticker",
    "الصور المتحركه": "animation",
}

from collections import defaultdict

user_mistakes = defaultdict(int)

def get_supported_commands_message():
    lines = []
    for key_en, key_ar in SUPPORTED_MEDIA_TYPES.items():
        lines.append(f"<blockquote>{key_ar} — قفل / فتح</blockquote>")
    return "\n".join(lines)

def handle_lock_unlock(message, action="قفل"):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id

    if not is_user_admin(int(chat_id), user_id):
        send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
        return

    try:
        media_type = message.text.split()[1].lower()
        media_type = ARABIC_MEDIA_TYPES.get(media_type, media_type)
    except:
        user_mistakes[user_id] += 1
        if user_mistakes[user_id] >= 3:
            user_mistakes[user_id] = 0
            send_pretty_message(
                chat_id,
                "<b>جننتني لك 3 مرات بترسل قفل وفتح\nهاي اوامر القفل والفتح لا تجنني!</b>\n" + get_supported_commands_message(),
                parse_mode="HTML"
            )
        else:
            send_pretty_message(
                chat_id,
                "يرجى تحديد نوع المحتوى:\n" + get_supported_commands_message(),
                parse_mode="HTML"
            )
        return

    if media_type not in SUPPORTED_MEDIA_TYPES:
        user_mistakes[user_id] += 1
        if user_mistakes[user_id] >= 3:
            user_mistakes[user_id] = 0
            send_pretty_message(
                chat_id,
                "<b>جننتني لك 3 مرات بترسل قفل وفتح\nهاي اوامر القفل والفتح لا تجنني!</b>\n" + get_supported_commands_message(),
                parse_mode="HTML"
            )
        else:
            send_pretty_message(
                chat_id,
                f"النوع <b>{media_type}</b> غير مدعوم.",
                parse_mode="HTML"
            )
        return

    user_mistakes[user_id] = 0  # تصفير العداد عند نجاح العملية

    data = load_group_json(chat_id, "locked_media.json")
    locked = set(data.get("locked", []))

    if action == "قفل":
        locked.add(media_type)
        save_group_json(chat_id, "locked_media.json", {"locked": list(locked)})
        send_pretty_message(chat_id, f"تم قفل <b>{SUPPORTED_MEDIA_TYPES[media_type]}</b> في المجموعة.", parse_mode="HTML")
    else:
        if media_type in locked:
            locked.remove(media_type)
            save_group_json(chat_id, "locked_media.json", {"locked": list(locked)})
            send_pretty_message(chat_id, f"تم فتح <b>{SUPPORTED_MEDIA_TYPES[media_type]}</b> في المجموعة.", parse_mode="HTML")
        else:
            send_pretty_message(chat_id, f"النوع <b>{SUPPORTED_MEDIA_TYPES[media_type]}</b> غير مقفل حالياً.", parse_mode="HTML")


# استدعاء الدالة مع الفلتر
@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith("قفل"))
def lock_media(message):
    handle_lock_unlock(message, action="قفل")

@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith("فتح"))
def unlock_media(message):
    handle_lock_unlock(message, action="فتح")

# دالة تتحقق من وجود رموز مميزة (custom emoji)
def contains_custom_emoji(message):
    entities = message.entities or []
    if message.caption_entities:
        entities += message.caption_entities
    for entity in entities:
        if entity.type == "custom_emoji":
            return True
    return False

@bot.message_handler(content_types=[
    'photo', 'video', 'document', 'audio',
    'voice', 'sticker', 'animation'
])
def filter_locked_media(message):
    chat_id = str(message.chat.id)
    data = load_group_json(chat_id, "locked_media.json")
    locked = set(data.get("locked", []))

    # الصور
    if "photo" in locked and message.photo:
        return bot.delete_message(chat_id, message.message_id)

    # الفيديو
    if "video" in locked and message.video:
        return bot.delete_message(chat_id, message.message_id)

    # الملفات
    if "document" in locked and message.document:
        return bot.delete_message(chat_id, message.message_id)

    # الصوتيات
    if "audio" in locked and message.audio:
        return bot.delete_message(chat_id, message.message_id)

    # المقاطع الصوتية
    if "voice" in locked and message.voice:
        return bot.delete_message(chat_id, message.message_id)

    # الملصقات
    if "sticker" in locked and message.sticker:
        return bot.delete_message(chat_id, message.message_id)

    # الصور المتحركة
    if "animation" in locked and message.animation:
        return bot.delete_message(chat_id, message.message_id)

    # لا تحذف الرسالة، خلّي المعالجات الثانية تشتغل
    pass

# تحميل معرفات الملصقات من ملف JSON
def load_meme_stickers():
    try:
        with open("meme/meme_stickers.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return []

# حفظ معرفات الملصقات إلى ملف JSON
def save_meme_stickers(data):
    with open("meme/meme_stickers.json", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# تحميل الملصقات عند بدء التشغيل
meme_stickers = load_meme_stickers()

# أمر كلمة "ميم"
@bot.message_handler(func=lambda message: message.text and message.text.strip() == "ميم")
def send_meme(message):
    try:
        chat_id = message.chat.id
        markup = types.InlineKeyboardMarkup(row_width=3)
        btn_photo = types.InlineKeyboardButton("📸 ميم صورة", callback_data="meme_photo")
        btn_video = types.InlineKeyboardButton("🎥 ميم فيديو", callback_data="meme_video")
        btn_sticker = types.InlineKeyboardButton("🖼️ ميم ملصق", callback_data="meme_sticker")
        markup.add(btn_photo, btn_video, btn_sticker)
        bot.send_message(chat_id, "هلا يا قلبي اختار شو بدك عندك ميم صور وميم فيديو وميم ملصقات", reply_markup=markup)
    except Exception as e:
        print("خطأ في أمر ميم:", e)
        traceback.print_exc()

# معالجة أزرار الميم
@bot.callback_query_handler(func=lambda call: call.data in ["meme_photo", "meme_video", "meme_sticker"])
def meme_choice_callback(call):
    try:
        chat_id = call.message.chat.id
        if call.data == "meme_sticker":
            if not meme_stickers:
                bot.send_message(chat_id, "⚠️ لا يوجد ميمات ملصق حالياً.")
                return
            sticker_id = random.choice(meme_stickers)
            bot.send_sticker(chat_id, sticker_id)
        else:
            folder = os.path.join("meme", "memephoto" if call.data == "meme_photo" else "memevideo")
            files = os.listdir(folder)
            if not files:
                bot.send_message(chat_id, "⚠️ لا يوجد ميمات حالياً في هذا القسم.")
                return
            file_choice = random.choice(files)
            file_path = os.path.join(folder, file_choice)
            with open(file_path, "rb") as media:
                if call.data == "meme_photo":
                    bot.send_photo(chat_id, media)
                else:
                    bot.send_video(chat_id, media)
        bot.answer_callback_query(call.id)
    except Exception as e:
        bot.send_message(chat_id, "حدث خطأ أثناء جلب الميم.")
        print("خطأ في callback الميم:", e)
        traceback.print_exc()


@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("كرة"))
def eight_ball(message):
    try:
        responses = [
            "أكيد طبعًا!",
            "لا أظن.",
            "احتمال كبير.",
            "مستحيل!",
            "جرب واسألني تاني.",
            "نعم بالتأكيد.",
            "ما عندي فكرة حالياً.",
            "يمكن، وممكن لا.",
            "فيه أمل بسيط.",
            "مش واضح، اسأل تاني."
        ]
        bot.reply_to(message, random.choice(responses))
    except Exception as e:
        print("خطأ في رد 8ball:", e)
        traceback.print_exc()

# /reverse - عكس النص المرسل (يجب أن يكون مع النص بعد الأمر)
@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("عكس"))
def reverse_text(message):
    try:
        chat_id = message.chat.id
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            send_pretty_message(chat_id, "يرجى كتابة النص بعد الكلمة.")
            return
        reversed_text = parts[1][::-1]
        send_pretty_message(chat_id, reversed_text)
    except Exception as e:
        print("خطأ في أمر عكس:", e)
        traceback.print_exc()

# /check - عرض معلومات مستخدم دون الرد (مثال: /check @username)
@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith("كشف"))
def check_user(message):
    try:
        chat_id = message.chat.id
        username = message.text.split()[1].lstrip("@")

        # نحاول نجيب قائمة المشرفين
        admins = bot.get_chat_administrators(chat_id)
        found = False
        for admin in admins:
            if admin.user.username and admin.user.username.lower() == username.lower():
                user = admin.user
                found = True
                break
        if not found:
            send_pretty_message(chat_id, "لم يتم العثور على المستخدم.")
            return

        user_info = f"👤 <b>معلومات المستخدم</b>:\n🆔 {user.id}\n📛 {user.first_name}"
        if hasattr(user, 'last_name') and user.last_name:
            user_info += f" {user.last_name}"
        if hasattr(user, 'username') and user.username:
            user_info += f"\n🔰 @{user.username}"

        # إذا فيه صورة بالرسالة، نرسلها مع الكلام
        if message.photo:
            file_id = message.photo[-1].file_id
            bot.send_photo(chat_id, file_id, caption=user_info, parse_mode="HTML")
        else:
            send_pretty_message(chat_id, user_info)
    except Exception as e:
        print("خطأ في أمر كشف:", e)
        traceback.print_exc()

# /pin - تثبيت رسالة (يجب الرد على الرسالة)
# أمر تثبيت الرسالة (يعمل مع /pin أو كلمة "تثبيت")
@bot.message_handler(func=lambda m: m.text and m.text.lower() in ["/pin", "تثبيت"])
def pin_message(message):
    try:
        chat_id = message.chat.id
        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return
        if not message.reply_to_message:
            send_pretty_message(chat_id, "يجب الرد على الرسالة التي تريد تثبيتها.")
            return
        bot.pin_chat_message(chat_id, message.reply_to_message.message_id)
        send_pretty_message(chat_id, "تم تثبيت الرسالة.")
    except Exception as e:
        print("خطأ في أمر تثبيت:", e)
        traceback.print_exc()

# أمر إلغاء التثبيت (يعمل مع /unpin أو كلمة "الغاء التثبيت")
@bot.message_handler(func=lambda m: m.text and m.text.lower() in ["/unpin", "الغاء التثبيت"])
def unpin_message(message):
    try:
        chat_id = message.chat.id
        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return
        bot.unpin_chat_message(chat_id)
        send_pretty_message(chat_id, "تم إلغاء تثبيت الرسالة.")
    except Exception as e:
        print("خطأ في أمر الغاء التثبيت:", e)
        traceback.print_exc()

from telethon.sync import TelegramClient

# دالة لجلب المشرفين
def get_admins(chat_id):
    try:
        admins = bot.get_chat_administrators(chat_id)
        return [admin.user.username for admin in admins if admin.user.username]
    except Exception as e:
        print(f"Error getting admins: {e}")
        return []

# دالة لفحص ما إذا كان المستخدم هو المالك أو مشرف
def get_user_type(chat_id, user_id):
    admins = get_admins(chat_id)
    for admin in admins:
        if admin == user_id:
            return "admin"
    return "owner"

@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith(("اعلان", "/announce")))
def announce(message):
    try:
        chat_id = message.chat.id
        user = message.from_user
        username = user.username or user.first_name or "مستخدم"

        user_type = get_user_type(chat_id, username)
        if user_type not in ["owner", "admin"]:
            bot.send_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return

        # استخراج نص الإعلان
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            bot.send_message(chat_id, "اكتب نص الإعلان بعد الكلمة.")
            return
        announcement = parts[1]

        user_label = "المالك" if user_type == "owner" else "الادمن"
        user_mention = f"{user_label} - @{username} يحتاجكم!"

        # جلب المشرفين
        admin_mentions = get_admins(chat_id)
        if admin_mentions:
            admin_mentions_text = "\n".join([f"@{admin}" for admin in admin_mentions])
        else:
            admin_mentions_text = "لا يوجد مشرفين إضافيين."

        full_announcement = f"{user_mention}\n\n{announcement}\n\n{admin_mentions_text}"
        bot.send_message(chat_id, full_announcement)

        # حذف الرسالة الأصلية (إذا أمكن)
        try:
            bot.delete_message(chat_id, message.message_id)
        except:
            pass  # تجاهل الخطأ لو ما عنده صلاحية
    except Exception as e:
        bot.send_message(chat_id, "حدث خطأ أثناء إرسال الإعلان.")
        print(f"خطأ في إعلان: {e}")

# /clean - حذف عدد معين من الرسائل (مثال: /clean 10)
# كلمة "تنظيف" بدلاً من أمر "/clean"
@bot.message_handler(func=lambda message: message.text.lower().startswith("مسح"))
def clean_messages(message):
    try:
        chat_id = message.chat.id
        if not is_user_admin(chat_id, message.from_user.id):
            send_pretty_message(chat_id, "يحرام انت مش مشرف له له له 💔😂")
            return
        try:
            count = int(message.text.split()[1])
        except:
            send_pretty_message(chat_id, "يرجى تحديد عدد الرسائل للحذف.")
            return
        # ملاحظة: حذف الرسائل يعتمد على صلاحيات البوت وقد لا يكون متاحاً لجميع الدردشات
        for i in range(count):
            try:
                bot.delete_message(chat_id, message.message_id - i)
            except:
                continue
        send_pretty_message(chat_id, f"تم حذف {count} رسالة.")
    except Exception as e:
        print("خطأ في أمر clean:", e)
        traceback.print_exc()

@bot.message_handler(func=lambda message: message.text.lower() == "الاعدادات")
def settings(message):
    try:
        chat_id = str(message.chat.id)
        group_dir = get_group_dir(chat_id)

        # رسالة الترحيب
        welcome_path = os.path.join(group_dir, "welcome.json")
        if os.path.exists(welcome_path):
            with open(welcome_path, "r", encoding="utf-8") as f:
                welcome_data = json.load(f)
            welcome_text = welcome_data.get("text", "نص ترحيب غير موجود")
            media_type = welcome_data.get("type")
            if media_type and media_type != "text":
                welcome_text += f" <i>(مع {media_type})</i>"
        else:
            welcome_text = "غير محددة"

        # القوانين
        rules_data = load_group_json(chat_id, "rules.json")
        rules_text = rules_data.get("text", "غير محددة")

        # الحذف التلقائي
        auto_data = load_group_json(chat_id, "auto_delete.json")
        delete_time = auto_data.get("seconds", "غير محدد")

        # الوسائط المقفولة
        lock_data = load_group_json(chat_id, "locked_media.json")
        locked_set = lock_data.get("locked", [])
        locked_text = ", ".join(locked_set) if locked_set else "لا يوجد"

        settings_text = (
            "<b>⚙️ إعدادات المجموعة:</b>\n\n"
            f"<b>• رسالة الترحيب:</b>\n<blockquote>{welcome_text}</blockquote>\n"
            f"<b>• قوانين المجموعة:</b>\n<blockquote>{rules_text}</blockquote>\n"
            f"<b>• زمن الحذف التلقائي:</b>\n<blockquote>{delete_time} ثانية</blockquote>\n"
            f"<b>• أنواع المحتوى المقفلة:</b>\n<blockquote>{locked_text}</blockquote>"
        )

        send_pretty_message(chat_id, settings_text, parse_mode="HTML")

    except Exception as e:
        print("خطأ في أمر settings:", e)
        traceback.print_exc()

# /stats - عرض إحصائيات المجموعة (عدد الأعضاء، المشرفين، إلخ)
@bot.message_handler(func=lambda message: message.text.lower() == "الاحصائيات")
def group_stats(message):
    try:
        chat_id = message.chat.id
        members_count = bot.get_chat_members_count(chat_id)
        admins = bot.get_chat_administrators(chat_id)
        stats_text = f"📊 <b>إحصائيات المجموعة:</b>\n- الأعضاء: {members_count}\n- المشرفين: {len(admins)}"
        send_pretty_message(chat_id, stats_text)
    except Exception as e:
        print("خطأ في أمر stats:", e)
        traceback.print_exc()

VIP_DIR = "vipscript"  # مجلد حفظ بيانات VIP
if not os.path.exists(VIP_DIR):
    os.makedirs(VIP_DIR)

VIP_FILE = os.path.join(VIP_DIR, "vip_data.json")      # بيانات فتحات VIP
COINS_FILE = os.path.join(VIP_DIR, "coins.json")         # بيانات رصيد المستخدمين

BOT_USERNAME = "@ChatGPTdarkbot"

# ======================================
# إعداد ملفات البيانات الخاصة بنظام VIP
# ======================================
def load_json(file_path, default):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return default

def save_json(file_path, data):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def load_vip_data():
    default = {
        "vip_users": [],
        "credits": {}  # {'user_id': available_slots}
    }
    return load_json(VIP_FILE, default)

def save_vip_data(data):
    save_json(VIP_FILE, data)

def load_coins():
    default = {}
    return load_json(COINS_FILE, default)

def save_coins(data):
    save_json(COINS_FILE, data)

def update_coins(user_id, amount):
    coins = load_coins()
    uid = str(user_id)
    coins[uid] = coins.get(uid, 0) + amount
    save_coins(coins)

def consume_vip_credit(user_id):
    data = load_vip_data()
    uid = str(user_id)
    if uid in data["credits"] and data["credits"][uid] > 0:
        data["credits"][uid] -= 1
        save_vip_data(data)

def has_vip_access(user_id):
    data = load_vip_data()
    return data.get("credits", {}).get(str(user_id), 0) > 0

def get_vip_credit(user_id):
    data = load_vip_data()
    return data.get("credits", {}).get(str(user_id), 0)

def get_user_coins(user_id):
    coins = load_coins()
    return coins.get(str(user_id), 0)

def get_file_slots(user_id):
    data = load_vip_data()
    return data.get("file_slots", {}).get(str(user_id), 0)

def clean_code(code):
    code = re.sub(r'^[^\n]*\n', '', code)
    code = re.sub(r'\n$', '', code)
    return code

def delete_after_delay(chat_id, message_id, delay=2):
    time.sleep(delay)
    try:
        bot.delete_message(chat_id, message_id)
    except Exception:
        pass

# ======================================
# دوال التعامل مع الملفات (dark_tool) - تم إزالتها
# ======================================
# تم حذف دوال فك الضغط و إعادة التعبئة و أكواد التحويلات

# ======================================
# آلية جدولة الطرد التلقائي (تم إزالتها)
# ======================================
# تم حذف الدوال المتعلقة بالطرد التلقائي

# ======================================
# إرسال الملف المعدل مع الرسالة (تم إزالتها)
# ======================================
# تم حذف دالة إرسال الملفات المعدلة

# ======================================
# الحصول على مجلدات المستخدم (تم إزالتها)
# ======================================
# تم حذف أكواد الحصول على مجلدات المستخدم

# ======================================
# متغيرات الحالة للمستخدمين (تم إزالتها)
# ======================================
# تم حذف متغيرات الحالة المرتبطة بالملفات والسكربتات

# ======================================
# أوامر VIP ولوحات المفاتيح - تم تعديلها
# ======================================
def create_vip_keyboard():
    keyboard = types.InlineKeyboardMarkup(row_width=2)
    keyboard.add(
        types.InlineKeyboardButton("○ مميزات السكربت ○", callback_data='vip_features_script')
    )
    keyboard.add(
        types.InlineKeyboardButton("○ تجميع رصيد ○", callback_data='vip_games')
    )
    keyboard.add(
        types.InlineKeyboardButton("○ شراء فتحات VIP ○", callback_data='vip_finance')
    )
    keyboard.add(
        types.InlineKeyboardButton("○ عدد فتحاتك ○", callback_data='show_balance'),
        types.InlineKeyboardButton("○ عدد رصيدك ○", callback_data='show_coins')
    )
    return keyboard

def create_admin_keyboard():
    keyboard = types.InlineKeyboardMarkup(row_width=2)
    # تم إزالة زر "DARK"
    keyboard.add(
        types.InlineKeyboardButton("منح تجربة مجانية", callback_data='give_vip')
    )
    keyboard.add(
        types.InlineKeyboardButton("إضافة رصيد", callback_data='add_coins')
    )
    return keyboard

def create_vip_games_keyboard():
    keyboard = types.InlineKeyboardMarkup(row_width=2)
    keyboard.add(
        types.InlineKeyboardButton("تحدي سهل 1", callback_data='game_rps'),
        types.InlineKeyboardButton("تحدي سهل 2", callback_data='game_guess_number')
    )
    keyboard.add(
        types.InlineKeyboardButton("تحدي متوسط 1", callback_data='game_math'),
        types.InlineKeyboardButton("تحدي متوسط 2", callback_data='game_scramble')
    )
    keyboard.add(
        types.InlineKeyboardButton("تحدي - الصعوبة 1", callback_data='game_memory'),
        types.InlineKeyboardButton("تحدي - الصعوبة 2", callback_data='game_advanced')
    )
    keyboard.add(
        types.InlineKeyboardButton("تحدي - الصعوبة 3", callback_data='game_extreme_210'),
        types.InlineKeyboardButton("تحدي - الصعوبة 4", callback_data='game_extreme_290')
    )
    keyboard.add(
        types.InlineKeyboardButton("رجوع", callback_data='back_to_vip_menu')
    )
    return keyboard

def create_vip_features_keyboard():
    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(
        types.InlineKeyboardButton("رجوع", callback_data='back_to_vip_menu')
    )
    return keyboard

# ======================================
# أوامر VIP
# ======================================
@bot.message_handler(commands=['vip'])
def handle_vip(message):
    user_id = message.from_user.id
    if user_id == ADMIN_ID:
        bot.send_message(message.chat.id, "مرحبا عزيزي الأدمن، اختر الخيارات التالية:", reply_markup=create_admin_keyboard())
    else:
        bot.send_message(message.chat.id, "مرحباً VIP! أهلاً بك في قسم VIP.", reply_markup=create_vip_keyboard())

@bot.message_handler(commands=['buyvipaccess'])
def buy_vipaccess(message):
    try:
        parts = message.text.split()
        if len(parts) < 2:
            bot.reply_to(message, "الاستخدام الصحيح: /buyvipaccess <عدد_الفتحات>")
            return
        count = int(parts[1])
        cost = count * 600  # سعر كل فتحة لطلب السكربت
        coins = load_coins()
        uid = str(message.from_user.id)
        user_balance = coins.get(uid, 0)
        if user_balance < cost:
            # تعديل رسالة الرصيد لتظهر كتنبيه في وسط الشاشة
            bot.send_message(message.chat.id, f"> رصيدك غير كافي.\nرصيدك: {user_balance}$\nالتكلفة المطلوبة: {cost}$")
            return
        coins[uid] = user_balance - cost
        save_coins(coins)
        data = load_vip_data()
        data["credits"][uid] = data["credits"].get(uid, 0) + count
        save_vip_data(data)
        bot.reply_to(message, f"تم شراء {count} فتحة VIP بنجاح!\nرصيدك المتبقي: {coins[uid]}$")
    except Exception as e:
        bot.reply_to(message, "حدث خطأ أثناء عملية الشراء. تأكد من صحة البيانات المدخلة.")

@bot.callback_query_handler(func=lambda call: call.data == 'show_balance')
def show_balance_callback(call):
    balance = get_vip_credit(call.from_user.id)
    # تعديل رسالة الرصيد لتظهر كتنبيه (alert) في وسط الشاشة
    bot.answer_callback_query(call.id, f"عدد فتحات VIP المتاحة لديك: {balance}", show_alert=True)

@bot.callback_query_handler(func=lambda call: call.data == 'show_coins')
def show_coins_callback(call):
    coins = get_user_coins(call.from_user.id)
    bot.answer_callback_query(call.id, f"رصيدك الحالي: {coins}$", show_alert=True)

@bot.callback_query_handler(func=lambda call: call.data == 'vip_finance')
def vip_finance_callback(call):
    msg = bot.send_message(call.message.chat.id, "اكتب عدد الفتحات التي تريد شرائها\nالسعر 600$ للفتحة الوحدة")
    bot.register_next_step_handler(msg, process_vip_purchase)

def process_vip_purchase(message):
    try:
        count = int(message.text)
        cost = count * 600
        coins = load_coins()
        uid = str(message.from_user.id)
        user_balance = coins.get(uid, 0)
        if user_balance < cost:
            bot.send_message(message.chat.id, f"> رصيدك غير كافي.\nرصيدك: {user_balance}$\nالتكلفة المطلوبة: {cost}$")
            return
        coins[uid] = user_balance - cost
        save_coins(coins)
        data = load_vip_data()
        data["credits"][uid] = data["credits"].get(uid, 0) + count
        save_vip_data(data)
        bot.reply_to(message, f"تم شراء {count} فتحة VIP بنجاح!\nرصيدك المتبقي: {coins[uid]}$")
    except Exception as e:
        bot.reply_to(message, "حدث خطأ أثناء عملية الشراء. تأكد من صحة البيانات المدخلة.")

@bot.callback_query_handler(func=lambda call: call.data == 'back_to_vip_menu')
def back_to_vip_menu(call):
    bot.edit_message_text("مرحباً بك في قسم VIP!\nاختر الخيار الذي تريده:",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id,
                          reply_markup=create_vip_keyboard())

# رسالة مميزات السكربت
@bot.callback_query_handler(func=lambda call: call.data == 'vip_features_script')
def vip_features_script(call):
    features_message = (
        "مميزات طلب سكربت:\n"
        "• برمجة سريعة ومخصصة حسب الطلب\n"
        "• تنفيذ الطلب دون تحية أو شرح زائد\n"
        "• دعم لجميع لغات البرمجة الشائعة\n"
        "• تسليم الملف مع رابط التحميل والمجموعة"
    )
    keyboard = create_vip_features_keyboard()
    bot.edit_message_text(features_message,
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id,
                          reply_markup=keyboard)

# ======================================
# طلب السكربت (الطلب قائم على النص)
# ======================================
@bot.callback_query_handler(func=lambda call: call.data == 'vip_request_script')
def vip_request_script(call):
    user_id = call.from_user.id
    if not has_vip_access(user_id):
        bot.answer_callback_query(call.id, "> ليس لديك فتحة VIP كافية 🗿", show_alert=True)
        return
    markup = types.InlineKeyboardMarkup()
    markup.add(
        types.InlineKeyboardButton("نعم", callback_data='confirm_request_script'),
        types.InlineKeyboardButton("لا", callback_data='cancel_request_script')
    )
    bot.edit_message_text("هل تريد استخدام فتحتك الحالية لطلب سكربت؟\n(ستستهلك فتحة واحدة عند المتابعة)\nسعر الطلب: 600$",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id,
                          reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data in ['confirm_request_script', 'cancel_request_script'])
def process_script_request_confirm(call):
    if call.data == 'cancel_request_script':
        bot.edit_message_text("تم إلغاء الطلب",
                              chat_id=call.message.chat.id,
                              message_id=call.message.message_id)
        return
    pending_script_requests[call.from_user.id] = True
    bot.edit_message_text("ارسل لي وصف الكود البرمجي المطلوب فقط",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id)
    bot.register_next_step_handler(call.message, handle_script_description)

def handle_script_description(message):
    if message.from_user.id not in pending_script_requests:
        return
    del pending_script_requests[message.from_user.id]
    user_id = message.from_user.id
    request_text = message.text
    bot.send_message(message.chat.id, "استنى... جاري برمجة الكود")
    full_request_text = ("اذا برمجت باللغة بايثون استخدم مكتبة telebot + bot polling() وبرمج اي شيئ معدا الغير قانوني ولا تضف أي شرح أو تحية، فقط نفذ الطلب التالي دون أي كلام: " + request_text)
    api_url = "https://dev-darkcre.pantheonsite.io/API/DARKBLACKGPT.php?text=" + requests.utils.quote(full_request_text) + "&lang=ar&style=female&dialect=palestinian"
    try:
        response = requests.get(api_url)
        script_content = response.text
        script_content = clean_code(script_content)
        ext = ".txt"
        if "<?php" in script_content:
            ext = ".php"
        elif "<html" in script_content.lower():
            ext = ".html"
        elif "#!/bin/bash" in script_content:
            ext = ".sh"
        elif "def " in script_content and ":" in script_content:
            ext = ".py"
        file_name = f"vipscript/script_{user_id}_{int(time.time())}{ext}"
        with open(file_name, "w", encoding="utf-8") as f:
            f.write(script_content)
        consume_vip_credit(user_id)
        
        caption = f"بعد تحميل الملف وحفظه\n@{message.from_user.username if message.from_user.username else message.from_user.first_name}"
        
        try:
            with open(file_name, "rb") as f:
                bot.send_document(user_id, f, caption=caption)
        except Exception:
            bot.send_message(message.chat.id, "حدث خطأ أثناء إرسال الملف.")
        
        bot.send_message(message.chat.id, 
                         f"@{message.from_user.username if message.from_user.username else message.from_user.first_name}\nتم برمجة الكود لك\nتم إرسال الملف بنجاح!")
    except Exception as e:
        bot.send_message(message.chat.id, "حدث خطأ أثناء تجهيز السكربت")

@bot.callback_query_handler(func=lambda call: call.data.startswith('goto_group_'))
def goto_group_callback(call):
    target_id = call.data.split('_')[-1]
    if str(call.from_user.id) != target_id:
        bot.answer_callback_query(call.id, "هذه العملية ليست لك!", show_alert=True)
        return
    bot.answer_callback_query(call.id, "تم إرسال الملف إلى الخاص.", show_alert=True)
    try:
        # تم إزالة رابط المجموعة هنا
        bot.send_message(
            call.from_user.id,
            f"○ <b>مرحبا بك</b>\nتم إرسال الملف إلى خاصك بنجاح.",
            parse_mode="HTML"
        )
    except Exception:
        bot.send_message(call.message.chat.id, "تعذر إرسال الملف إلى الخاص، تأكد من بدء الدردشة مع البوت.")

# ======================================
# باقي أوامر الألعاب والنظام (كما هي في السكربت الأصلي)
# ======================================
@bot.callback_query_handler(func=lambda call: call.data == 'vip_games')
def vip_games_handler(call):
    keyboard = create_vip_games_keyboard()
    bot.edit_message_text("اختر لعبة من القائمة التالية:",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id,
                          reply_markup=keyboard)

@bot.callback_query_handler(func=lambda call: call.data == 'game_guess_number')
def start_guess_game(call):
    target = random.randint(1, 10)
    guess_sessions = {}
    guess_sessions[str(call.from_user.id)] = target
    bot.edit_message_text("لعبة تخمين الرقم:\nاختر رقمًا بين 1 و 10:",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id)
    bot.register_next_step_handler(call.message, lambda msg: process_guess_game(msg, guess_sessions))

def process_guess_game(message, sessions):
    uid = str(message.from_user.id)
    if uid not in sessions:
        bot.reply_to(message, "انتهت جلسة اللعبة، اضغط على قسم الألعاب لبدء لعبة جديدة.")
        return
    try:
        guess = int(message.text)
    except ValueError:
        bot.reply_to(message, "يرجى إدخال رقم صحيح.")
        return
    target = sessions[uid]
    if guess == target:
        update_coins(message.from_user.id, 30)
        coins = load_coins()
        new_balance = coins.get(uid, 0)
        bot.reply_to(message, f"ممتاز! الرقم الصحيح هو {target}.\n🎉 حصلت على 30 رصيد!\nرصيدك الحالي: {new_balance}$")
    else:
        bot.reply_to(message, f"للأسف، الرقم الصحيح كان: {target}.")
    del sessions[uid]

@bot.callback_query_handler(func=lambda call: call.data == 'game_rps')
def start_rps_game(call):
    keyboard = types.InlineKeyboardMarkup(row_width=3)
    keyboard.add(
        types.InlineKeyboardButton("حجر", callback_data='rps_rock'),
        types.InlineKeyboardButton("ورقة", callback_data='rps_paper'),
        types.InlineKeyboardButton("مقص", callback_data='rps_scissors')
    )
    bot.edit_message_text("لعبة حجر ورقة مقص:\nاختر أحد الخيارات:",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id,
                          reply_markup=keyboard)

@bot.callback_query_handler(func=lambda call: call.data.startswith('rps_'))
def process_rps_game(call):
    user_choice = call.data.split('_')[1]
    options = ['rock', 'paper', 'scissors']
    bot_choice = random.choice(options)
    if user_choice == bot_choice:
        result = "تعادل!"
        win = False
    elif (user_choice == 'rock' and bot_choice == 'scissors') or \
         (user_choice == 'paper' and bot_choice == 'rock') or \
         (user_choice == 'scissors' and bot_choice == 'paper'):
        result = "فزت!"
        win = True
    else:
        result = "خسرت!"
        win = False
    mapping = {'rock': 'حجر', 'paper': 'ورقة', 'scissors': 'مقص'}
    message_text = f"اخترت: {mapping[user_choice]}\nالبوت اختار: {mapping[bot_choice]}\nالنتيجة: {result}"
    if win:
        update_coins(call.from_user.id, 30)
        coins = load_coins()
        new_balance = coins.get(str(call.from_user.id), 0)
        message_text += f"\n🎉 حصلت على 30 رصيد!\nرصيدك الحالي: {new_balance}$"
    bot.edit_message_text(message_text,
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id)

@bot.callback_query_handler(func=lambda call: call.data == 'game_math')
def start_math_game(call):
    num1 = random.randint(10, 50)
    num2 = random.randint(1, 20)
    operator = random.choice(['+', '-', '*'])
    expression = f"{num1} {operator} {num2}"
    try:
        answer = eval(expression)
    except Exception:
        answer = None
    math_sessions = {}
    math_sessions[str(call.from_user.id)] = answer
    bot.edit_message_text(f"مسابقة الرياضيات:\nأوجد نتيجة العملية:\n{expression}",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id)
    bot.register_next_step_handler(call.message, lambda msg: process_math_game(msg, math_sessions))

def process_math_game(message, sessions):
    uid = str(message.from_user.id)
    if uid not in sessions:
        bot.reply_to(message, "انتهت جلسة اللعبة، اضغط على قسم الألعاب لبدء لعبة جديدة.")
        return
    try:
        user_answer = float(message.text.strip())
    except ValueError:
        bot.reply_to(message, "يرجى إدخال رقم صحيح/عشري كإجابة.")
        return
    correct_answer = sessions[uid]
    if abs(user_answer - correct_answer) < 0.001:
        update_coins(message.from_user.id, 60)
        coins = load_coins()
        new_balance = coins.get(uid, 0)
        bot.reply_to(message, f"إجابة صحيحة! الجواب هو {correct_answer}.\n🎉 حصلت على 60 رصيد!\nرصيدك الحالي: {new_balance}$")
    else:
        bot.reply_to(message, f"إجابة خاطئة! الجواب الصحيح هو {correct_answer}.")
    del sessions[uid]

@bot.callback_query_handler(func=lambda call: call.data == 'game_scramble')
def start_scramble_game(call):
    words = ["برمجة", "استثنائي", "تحدي", "متفرد", "مُعقّد"]
    word = random.choice(words)
    scrambled = list(word)
    random.shuffle(scrambled)
    scrambled_word = ''.join(scrambled)
    scramble_sessions = {}
    scramble_sessions[str(call.from_user.id)] = word
    bot.edit_message_text(f"لغز الحروف:\nرتب الحروف لتكوين الكلمة الصحيحة:\n{scrambled_word}",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id)
    bot.register_next_step_handler(call.message, lambda msg: process_scramble_game(msg, scramble_sessions))

def process_scramble_game(message, sessions):
    uid = str(message.from_user.id)
    if uid not in sessions:
        bot.reply_to(message, "انتهت جلسة اللعبة، اضغط على قسم الألعاب لبدء لعبة جديدة.")
        return
    correct_word = sessions[uid]
    if message.text.strip() == correct_word:
        update_coins(message.from_user.id, 60)
        coins = load_coins()
        new_balance = coins.get(uid, 0)
        bot.reply_to(message, f"أحسنت! الكلمة الصحيحة هي {correct_word}.\n🎉 حصلت على 60 رصيد!\nرصيدك الحالي: {new_balance}$")
    else:
        bot.reply_to(message, f"للأسف، الإجابة خاطئة! الكلمة الصحيحة هي {correct_word}.")
    del sessions[uid]

@bot.callback_query_handler(func=lambda call: call.data == 'game_memory')
def start_memory_game(call):
    sequence = ''.join([str(random.randint(0, 9)) for _ in range(6)])
    memory_sessions = {}
    memory_sessions[str(call.from_user.id)] = sequence
    sent_msg = bot.send_message(call.message.chat.id, f"تحدي الذاكرة:\nاحفظ هذه السلسلة لمدة 3 ثواني:\n{sequence}")
    threading.Timer(3, finish_memory_game, args=(call.message.chat.id, sent_msg.message_id, call, memory_sessions)).start()

def finish_memory_game(chat_id, message_id, call, sessions):
    try:
        bot.delete_message(chat_id, message_id)
    except Exception:
        pass
    bot.send_message(chat_id, "الآن، اكتب السلسلة التي رأيتها:")
    bot.register_next_step_handler(call.message, lambda msg: process_memory_game(msg, sessions))

def process_memory_game(message, sessions):
    uid = str(message.from_user.id)
    if uid not in sessions:
        bot.reply_to(message, "انتهت جلسة اللعبة، اضغط على قسم الألعاب لبدء لعبة جديدة.")
        return
    correct_sequence = sessions[uid]
    if message.text.strip() == correct_sequence:
        update_coins(message.from_user.id, 60)
        coins = load_coins()
        new_balance = coins.get(uid, 0)
        bot.reply_to(message, f"إجابة صحيحة! السلسلة كانت {correct_sequence}.\n🎉 حصلت على 60 رصيد!\nرصيدك الحالي: {new_balance}$")
    else:
        bot.reply_to(message, f"للأسف، الإجابة خاطئة! السلسلة الصحيحة هي {correct_sequence}.")
    del sessions[uid]

@bot.callback_query_handler(func=lambda call: call.data == 'game_advanced')
def start_advanced_game(call):
    a = random.randint(5, 20)
    b = random.randint(5, 20)
    c = random.randint(2, 10)
    d = random.randint(1, 10)
    expression = f"(({a} + {b}) * {c} - {d})"
    try:
        answer = eval(expression)
    except Exception:
        answer = None
    advanced_sessions = {}
    advanced_sessions[str(call.from_user.id)] = answer
    bot.edit_message_text(f"تحدي العقل:\nاحسب ناتج العملية التالية:\n{expression}",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id)
    bot.register_next_step_handler(call.message, lambda msg: process_advanced_game(msg, advanced_sessions))

def process_advanced_game(message, sessions):
    uid = str(message.from_user.id)
    if uid not in sessions:
        bot.reply_to(message, "انتهت جلسة اللعبة، اضغط على قسم الألعاب لبدء لعبة جديدة.")
        return
    try:
        user_answer = float(message.text.strip())
    except ValueError:
        bot.reply_to(message, "يرجى إدخال رقم صحيح/عشري كإجابة.")
        return
    correct_answer = sessions[uid]
    if abs(user_answer - correct_answer) < 0.001:
        update_coins(message.from_user.id, 120)
        coins = load_coins()
        new_balance = coins.get(uid, 0)
        bot.reply_to(message, f"إجابة صحيحة! الجواب هو {correct_answer}.\n🎉 حصلت على 120 رصيد!\nرصيدك الحالي: {new_balance}$")
    else:
        bot.reply_to(message, f"إجابة خاطئة! الجواب الصحيح هو {correct_answer}.")
    del sessions[uid]

@bot.callback_query_handler(func=lambda call: call.data == 'game_extreme_210')
def start_extreme210_game(call):
    a = random.randint(2, 5)
    b = random.randint(2, 5)
    c = random.randint(2, 5)
    d = random.randint(1, 5)
    expression = f"({a}**2 + {b}**2) - ({c}**2 - {d})"
    try:
        answer = eval(expression)
    except Exception:
        answer = None
    extreme210_sessions = {}
    extreme210_sessions[str(call.from_user.id)] = answer
    bot.edit_message_text(f"تحدي العقل 210:\nاحسب ناتج العملية التالية:\n{expression}",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id)
    bot.register_next_step_handler(call.message, lambda msg: process_extreme210_game(msg, extreme210_sessions))

def process_extreme210_game(message, sessions):
    uid = str(message.from_user.id)
    if uid not in sessions:
        bot.reply_to(message, "انتهت جلسة اللعبة، اضغط على قسم الألعاب لبدء لعبة جديدة.")
        return
    try:
        user_answer = float(message.text.strip())
    except ValueError:
        bot.reply_to(message, "يرجى إدخال رقم صحيح/عشري كإجابة.")
        return
    correct_answer = sessions[uid]
    if abs(user_answer - correct_answer) < 0.001:
        update_coins(message.from_user.id, 210)
        coins = load_coins()
        new_balance = coins.get(uid, 0)
        bot.reply_to(message, f"إجابة صحيحة! الجواب هو {correct_answer}.\n🎉 حصلت على 210 رصيد!\nرصيدك الحالي: {new_balance}$")
    else:
        bot.reply_to(message, f"للأسف، الإجابة خاطئة! الجواب الصحيح هو {correct_answer}.")
    del sessions[uid]

@bot.callback_query_handler(func=lambda call: call.data == 'game_extreme_290')
def start_extreme290_game(call):
    a = random.randint(3, 6)
    b = random.randint(2, 5)
    c = random.randint(1, 3)
    d = random.randint(1, 4)
    expression = f"({a}**3 - {b}**3) / ({c} + {d})"
    try:
        answer = eval(expression)
    except Exception:
        answer = None
    extreme290_sessions = {}
    extreme290_sessions[str(call.from_user.id)] = answer
    bot.edit_message_text(f"تحدي العقل 290:\nاحسب ناتج العملية التالية:\n{expression}",
                          chat_id=call.message.chat.id,
                          message_id=call.message.message_id)
    bot.register_next_step_handler(call.message, lambda msg: process_extreme290_game(msg, extreme290_sessions))

def process_extreme290_game(message, sessions):
    uid = str(message.from_user.id)
    if uid not in sessions:
        bot.reply_to(message, "انتهت جلسة اللعبة، اضغط على قسم الألعاب لبدء لعبة جديدة.")
        return
    try:
        user_answer = float(message.text.strip())
    except ValueError:
        bot.reply_to(message, "يرجى إدخال رقم صحيح/عشري كإجابة.")
        return
    correct_answer = sessions[uid]
    if abs(user_answer - correct_answer) < 0.001:
        update_coins(message.from_user.id, 290)
        coins = load_coins()
        new_balance = coins.get(uid, 0)
        bot.reply_to(message, f"إجابة صحيحة! الجواب هو {correct_answer}.\n🎉 حصلت على 290 رصيد!\nرصيدك الحالي: {new_balance}$")
    else:
        bot.reply_to(message, f"للأسف، الإجابة خاطئة! الجواب الصحيح هو {correct_answer}.")
    del sessions[uid]
    
# ======================================
# وظيفة منح فتحات VIP من قبل الأدمن
# ======================================
@bot.callback_query_handler(func=lambda call: call.data == 'give_vip')
def give_vip_callback(call):
    if call.from_user.id != ADMIN_ID:
        bot.answer_callback_query(call.id, "أنت لست الأدمن!", show_alert=True)
        return
    msg = bot.send_message(call.message.chat.id, "أدخل رقم المستخدم (ID) الذي تريد منحه VIP:")
    bot.register_next_step_handler(msg, process_give_vip_username)

def process_give_vip_username(message):
    if message.from_user.id != ADMIN_ID:
        return
    target_id_str = message.text.strip()
    if not target_id_str.isdigit():
        bot.send_message(message.chat.id, "الرجاء إدخال رقم المستخدم (ID) الصحيح وليس اسم المستخدم.")
        return
    bot.send_message(message.chat.id, f"تم استلام الرقم {target_id_str}.\nالآن أدخل عدد الفتحات التي تريد إضافتها:")
    bot.register_next_step_handler(message, lambda msg: process_give_vip_usage(msg, target_id_str))

def process_give_vip_usage(message, target_id_str):
    if message.from_user.id != ADMIN_ID:
        return
    try:
        usage_count = int(message.text.strip())
    except ValueError:
        bot.reply_to(message, "يرجى إدخال رقم صحيح لعدد الاستخدامات.")
        return
    data = load_vip_data()
    data["credits"][target_id_str] = data.get("credits", {}).get(target_id_str, 0) + usage_count
    save_vip_data(data)
    bot.send_message(message.chat.id, f"تم منح المستخدم {target_id_str} {usage_count} فتحة VIP.")

# ======================================
# وظيفة إضافة رصيد من قبل الأدمن
# ======================================
@bot.callback_query_handler(func=lambda call: call.data == 'add_coins')
def add_coins_callback(call):
    if call.from_user.id != ADMIN_ID:
        bot.answer_callback_query(call.id, "أنت لست الأدمن!", show_alert=True)
        return
    msg = bot.send_message(call.message.chat.id, "أدخل رقم المستخدم (ID) الذي تريد إضافة رصيد له:")
    bot.register_next_step_handler(msg, process_add_coins_user)

def process_add_coins_user(message):
    if message.from_user.id != ADMIN_ID:
        return
    target_id_str = message.text.strip()
    if not target_id_str.isdigit():
        bot.send_message(message.chat.id, "الرجاء إدخال رقم المستخدم (ID) الصحيح وليس اسم المستخدم.")
        return
    bot.send_message(message.chat.id, f"تم استلام الرقم {target_id_str}.\nالآن أدخل مبلغ الرصيد الذي تريد إضافته:")
    bot.register_next_step_handler(message, lambda msg: process_add_coins_amount(msg, target_id_str))

def process_add_coins_amount(message, target_id_str):
    if message.from_user.id != ADMIN_ID:
        return
    try:
        amount = int(message.text.strip())
    except ValueError:
        bot.reply_to(message, "يرجى إدخال رقم صحيح للمبلغ.")
        return
    coins = load_coins()
    coins[target_id_str] = coins.get(target_id_str, 0) + amount
    save_coins(coins)
    bot.send_message(message.chat.id, f"تم إضافة {amount}$ للمستخدم {target_id_str}.")

waiting_whisper = {}

def create_whisper_button():
    button = telebot.types.InlineKeyboardButton("✉️ كتابة همسة", url="https://t.me/ChatGPTdarkbot")
    keyboard = telebot.types.InlineKeyboardMarkup()
    keyboard.add(button)
    return keyboard

def create_view_whisper_button(target_user_id):
    button = telebot.types.InlineKeyboardButton(
        "👀 رؤية الهمسة", 
        url=f"https://t.me/ChatGPTdarkbot?start=whisper_{target_user_id}"
    )
    keyboard = telebot.types.InlineKeyboardMarkup()
    keyboard.add(button)
    return keyboard

# التعامل مع الرسائل التي تحتوي على "همسه" أو "ه" وتكون كرد على رسالة مستخدم آخر
@bot.message_handler(func=lambda message: 
    message.text is not None and 
    (("همسه" in message.text.lower()) or (message.text.lower().strip() == "ه")) and 
    (message.reply_to_message is not None)
)
def handle_whisper_request(message):
    target_user_id = message.reply_to_message.from_user.id
    sender_id = message.from_user.id
    group_chat_id = message.chat.id
    # حفظ معرف رسالة المستخدم الذي تم الرد عليه (الهدف)
    reply_message_id = message.reply_to_message.message_id  
    target_username = message.reply_to_message.from_user.username or message.reply_to_message.from_user.first_name

    # حفظ بيانات المستخدم المستهدف مع معلومات المجموعة واسم المستخدم الخاص به
    waiting_whisper[sender_id] = {
        "target": target_user_id,
        "chat_id": group_chat_id,
        "reply_id": reply_message_id,
        "target_username": target_username
    }

    # إرسال رسالة خاصة تطلب من المستخدم كتابة الهمسة
    bot.send_message(sender_id, "اكتب رسالتك")
    
    keyboard = create_whisper_button()
    bot.reply_to(
        message, 
        "تم تفعيل وضع الهمسة، انتقل للخاص مع البوت واكتب همستك!", 
        reply_markup=keyboard
    )

@bot.message_handler(func=lambda message: message.from_user.id in waiting_whisper)
def handle_writing_whisper(message):
    # تجاهل أي رسالة ليست في الدردشة الخاصة
    if message.chat.type != "private":
        return  

    sender_id = message.from_user.id
    data = waiting_whisper[sender_id]
    target_user_id = data["target"]
    group_chat_id = data["chat_id"]
    reply_message_id = data["reply_id"]
    whisper_text = message.text

    # إرسال الهمسة للمستخدم المستهدف مع ذكر المُرسِل
    sender_username = message.from_user.username or message.from_user.first_name
    final_text = f"رسالة خاصة لك من @{sender_username}:\nالرساله : {whisper_text}"
    bot.send_message(target_user_id, final_text)

    # إرسال رسالة في المجموعة على رسالة المستخدم الهدف مع زر "رؤية الهمسة"
    group_message = f"تم إرسال لك همسة خاصة لـ @{data['target_username']}!"
    view_button = create_view_whisper_button(target_user_id)
    bot.send_message(
        group_chat_id,
        group_message,
        reply_to_message_id=reply_message_id,
        reply_markup=view_button
    )

    # تأكيد الإرسال للمُرسِل في الخاص وحذف رسالته
    bot.send_message(sender_id, "تم إرسال الهمسة بنجاح!")
    bot.delete_message(sender_id, message.message_id)

    # إزالة بيانات المستخدم من قائمة الانتظار
    del waiting_whisper[sender_id]   

# إضافة ميزة الترجمة
@bot.message_handler(func=lambda message: 'ترجمي' in message.text)
def handle_translation(message):
    text = message.text
    content = text.replace("ترجمي", "").strip()
    target_lang = None

    arabic_langs = {
        'للانجليزيه': 'en',
        'للفرنسيه': 'fr',
        'للالمانيه': 'de',
        'للاسبانيه': 'es',
        'للايطاليه': 'it',
        'للروسيه': 'ru',
        'للعربيه': 'ar',
        'للتركيه': 'tr',
        'لليابانيه': 'ja',
        'للصينيه': 'zh-CN',
        'لهنديه': 'hi',
        'للكوريه': 'ko',
    }

    for lang in arabic_langs.keys():
        if content.endswith(f"{lang}"):
            target_lang = arabic_langs[lang]
            content = content.replace(f"{lang}", "").strip()
            break

    if target_lang:
        translated = GoogleTranslator(source='auto', target=target_lang).translate(content)
        bot.reply_to(message, translated)
    else:
        bot.reply_to(message, "أرجو تحديد اللغة الصحيحة بعد كلمة 'ترجمي'.")

# قائمة الملصقات
stickers = [
    "CAACAgIAAxkBAAINhGff_09lgc3tmFUhEt3_OcF8E-5zAAILAAMOR8coqKD0-uKs4cE2BA",
    "CAACAgIAAxkBAAINiGff_3FaSeydA9Is4NLIXitsqIyXAAIMAAMOR8coXHFJch0-25E2BA",
    "CAACAgIAAxkBAAINimff_48is2Qx3pYLE-3rAe6WXYCLAAINAAMOR8cojPFAhGcH06g2BA",
    "CAACAgIAAxkBAAINjGff_6TELWyoN13LN1ZwPrYtkJYqAAIOAAMOR8co1hNgkbBsfpk2BA",
    "CAACAgIAAxkBAAINjmff_7T5BNL-xBUvxT1mEkwhnhSVAAITAAMOR8coxh4Tw1EGPDY2BA",
    "CAACAgIAAxkBAAINkGff_8_QZ1KZt9pdJWIHYBJhEkl_AAIPAAMOR8coKchfPDiosqM2BA",
    "CAACAgIAAxkBAAINkmff_-zHzkYWT5RvNOoe0NWt5ZCYAAIQAAMOR8coGTkcoszrSp82BA",
    "CAACAgIAAxkBAAINlmfgAAE7jKjdLgYmo7sT0k5Mwa_66QACEQADDkfHKHeBfoYMOnnDNgQ",
    "CAACAgIAAxkBAAINmGfgAAFgceo3wA-xLA4V4Gb1cLr5BAACEgADDkfHKATauSzHGIhqNgQ",
    "CAACAgIAAxkBAAINmmfgAAGSbkq9eLBG-W7CEvJpg4wsXwACJAADDkfHKJNLLIxtMLmDNgQ"
]

# إعدادات API (يستخدمها سكربت آخر)
API_HASH = "1bb27e5be73593e33fc735c1fbe0d855"
API_ID = 25217515

# متغيرات عامة
downloadLinks = {}      # لتخزين روابط التحميل مؤقتاً
processing = {}         # لتخزين حالة العمليات (مثل عملية الصورة) لكل مستخدم
user_msg_count = {}     # عداد رسائل المستخدمين
active_chats = {}       # حالة تفعيل البوت في المجموعات
stats = {"active_groups": 0, "groups": 0}
blocked_requests = []   # قائمة الطلبات المحظورة
WELCOME_IMAGE = "welcome.jpg"  # صورة الترحيب (تأكد من وجودها)

# --------------------------
# دوال مساعدة (يجب تعريفها أو تعديلها بما يناسب تطبيقك)
def is_subscribed(user_id):
    # يجب تنفيذ الدالة للتحقق من اشتراك المستخدم في القناة
    return True

def send_subscription_message(chat_id):
    bot.send_message(chat_id, "يرجى الاشتراك بالقناة لتفعيل البوت.")

def add_new_user(user_id):
    # إضافة المستخدم إلى قاعدة البيانات إن لزم الأمر
    pass

def save_data(filename, data):
    # حفظ بيانات المستخدمين أو المجموعة
    pass

def save_stats():
    # حفظ الإحصائيات
    pass

def get_random_activation_reply():
    return "تم تفعيل حلا في المجموعة!"

def get_random_deactivation_reply():
    return "تم إيقاف حلا في المجموعة."

def format_text(text):
    # تنسيق النص حسب الحاجة
    return text.strip()

import os
import re
import uuid
import threading
import requests
from telebot import TeleBot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, InputMediaPhoto

# تخزين الكاش في قاموس، وكل مفتاح سيكون "chat_id_user_id"
search_cache = {}

def shorten_number(n):
    try:
        if isinstance(n, str):
            n = int(re.sub(r'[^\d]', '', n))  # إزالة الرموز والفواصل
        if n >= 1_000_000:
            return f"{n // 1_000_000} مليون"
        elif n >= 1_000:
            return f"{n // 1_000} ألف"
        else:
            return str(n)
    except:
        return str(n)

def duration_to_seconds(dur_str):
    try:
        parts = list(map(int, dur_str.split(":")))
        if len(parts) == 2:
            return parts[0]*60 + parts[1]
        elif len(parts) == 3:
            return parts[0]*3600 + parts[1]*60 + parts[2]
    except:
        return 0

def get_thumbnail(url):
    # استخراج صورة الفيديو من يوتيوب إن وُجد
    youtube_match = re.search(r"(?:v=|youtu\.be/)([^&\s]+)", url)
    if youtube_match:
        video_id = youtube_match.group(1)
        return f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg"
    return None

def search_youtube(query):
    """
    استخدام API البحث الجديد للحصول على نتائج يوتيوب.
    API جديدة ترجع قائمة من النتائج.
    """
    try:
        response = requests.get(f"http://145.223.80.56:5010/Api-Search-YouTube?search={query}")
        if response.status_code != 200:
            return None
        data = response.json()
        return data  # نتوقع الحصول على قائمة من النتائج
    except Exception as e:
        print(f"Error searching YouTube: {e}")
        return None

def old_download_api(video_url):
    """
    استخدام API القديم للحصول على رابط تحميل الملف (mp3)
    بناءً على رابط الفيديو.
    """
    try:
        response = requests.get(f"https://ochinpo-helper.hf.space/yt?query={video_url}")
        if response.status_code != 200:
            return None
        data = response.json()
        if not data.get("success"):
            return None
        return data["result"]
    except Exception as e:
        print(f"Error in old download API: {e}")
        return None

def downloadFile(url, filename, timeout=300, check_size=True, max_size=5):
    """
    تحميل الملف من الرابط وتخزينه بالاسم filename.
    إذا كان check_size مفعلًا، يتم التحقق من أن حجم الملف لا يتجاوز max_size ميجابايت.
    """
    try:
        with requests.get(url, stream=True, timeout=timeout) as response:
            if response.status_code == 200:
                if check_size:
                    size = response.headers.get('content-length')
                    if size is not None:
                        size_mb = int(size) / (1024 * 1024)
                        if size_mb > max_size:
                            return "too_large"
                with open(filename, "wb") as f:
                    for chunk in response.iter_content(1024):
                        f.write(chunk)
                return filename
    except Exception as e:
        print(f"Error downloading file: {e}")
    return None

def shorten_number(n):
    try:
        if isinstance(n, str):
            n = re.sub(r"[^\d]", "", n)  # إزالة أي شيء غير رقمي
            n = int(n)
        if n >= 1_000_000_000:
            return f"{n // 1_000_000_000} مليار"
        elif n >= 1_000_000:
            return f"{n // 1_000_000} مليون"
        elif n >= 1_000:
            return f"{n // 1_000} ألف"
        else:
            return str(n)
    except:
        return str(n)

def build_caption(info):
    if isinstance(info.get('duration'), dict):
        duration = info['duration']['timestamp']
        duration_seconds = info['duration'].get('seconds', 0)
    else:
        duration = info.get('duration', "")
        duration_seconds = duration_to_seconds(duration)

    title = info.get('title', "")
    uploader = info.get('uploader') or (info.get('author', {}) or {}).get('name', "")

    views = info.get('views', "")
    views_short = shorten_number(views)
    published = localize_published(info.get('published_time', ""))

    note = ""
    if duration_seconds > 300:
        note = "\n⚠️ <i>مدّة الملف تتجاوز 5 دقائق، لا يمكن تحميله.</i>"

    caption = (
        f"<b></b>\n<blockquote>{uploader} 🦋</blockquote>\n"
        f"<b>Views - </b> {views_short} 😉\n"
        f"<b>Duration - </b> {duration} 🕒\n"
        f"<b>date - </b> {published} 🫣\n"
        f"<b></b><blockquote>{title} ❤️‍🔥</blockquote>\n"
        f"{note}"
    )
    return caption
    
def localize_published(published):
    if not published:
        return ""
    replacements = {
        "vor ": "",
        "Monaten": "أشهر",
        "Monat": "شهر",
        "Wochen": "أسابيع",
        "Woche": "أسبوع",
        "Tagen": "أيام",
        "Tag": "يوم",
        "Stunden": "ساعات",
        "Stunde": "ساعة",
        "Minuten": "دقائق",
        "Minute": "دقيقة",
    }
    for k, v in replacements.items():
        published = published.replace(k, v)
    return published.strip()

# مستمع الأمر "بحث"
@bot.message_handler(regexp=r"^بحث (.+)")
def info_handler(message):
    query = message.text.split(" ", 1)[1]
    loading_msg = bot.reply_to(message, "جاري البحث...")
    results = search_youtube(query)
    try:
        bot.delete_message(message.chat.id, loading_msg.message_id)
    except Exception as e:
        print(f"Error deleting loading message: {e}")
    if not results:
        bot.reply_to(message, "ما لقيت نتيجة 🥹")
        return

    # استخدام مفتاح مركب لكل مستخدم: chat_id_user_id
    key = f"{message.chat.id}_{message.from_user.id}"
    search_cache[key] = {
        'results': results,
        'index': 0,
        'query': query,
        'reply_to': message.message_id,
        'user_id': message.from_user.id
    }
    send_result(key)

def send_result(key, edit=False, msg_obj=None):
    cache = search_cache.get(key)
    if not cache:
        return
    index = cache['index']
    results = cache['results']
    if index < 0 or index >= len(results):
        bot.send_message(key.split("_")[0], "لا توجد نتيجة بهذا الرقم.")
        return
    info = results[index]
    # محاولة استخراج الصورة المصغرة إذا لم تكن موجودة
    if not info.get('thumbnail'):
        thumbnail = get_thumbnail(info.get('url', ''))
        info['thumbnail'] = thumbnail or ""
    markup = InlineKeyboardMarkup(row_width=3)
    buttons = []
    if index > 0:
        buttons.append(InlineKeyboardButton("⬅️ رجوع", callback_data="prev"))
    if duration_to_seconds(info.get('duration', "")) <= 300:
        buttons.append(InlineKeyboardButton("تحميل ⬇️", callback_data="download"))
    if index < len(results) - 1:
        buttons.append(InlineKeyboardButton("التالي ▶️", callback_data="next"))
    markup.add(*buttons)
    caption = build_caption(info)
    chat_id = key.split("_")[0]
    if edit:
        try:
            media = InputMediaPhoto(media=info['thumbnail'], caption=caption, parse_mode='HTML')
            bot.edit_message_media(
                media=media,
                chat_id=chat_id,
                message_id=msg_obj.message_id,
                reply_markup=markup
            )
        except Exception as e:
            print(f"Edit message failed: {e}")
    else:
        bot.send_photo(
            chat_id,
            photo=info['thumbnail'],
            caption=caption,
            parse_mode="HTML",
            reply_markup=markup,
            reply_to_message_id=cache['reply_to']
        )

@bot.callback_query_handler(func=lambda c: c.data in ['next', 'prev', 'download'])
def callback_handler(call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    key = f"{chat_id}_{user_id}"
    if key not in search_cache:
        bot.answer_callback_query(call.id, "انتهت الجلسة، اكتب بحث جديد.")
        return
    cache = search_cache[key]
    # التحقق من هوية المستخدم (بالرغم من أن المفتاح يشمل user_id)
    if user_id != cache.get('user_id'):
        bot.answer_callback_query(call.id, "البحث مو لك", show_alert=True)
        return

    if call.data == "next":
        if cache['index'] < len(cache['results']) - 1:
            cache['index'] += 1
            send_result(key, edit=True, msg_obj=call.message)
        bot.answer_callback_query(call.id)
    elif call.data == "prev":
        if cache['index'] > 0:
            cache['index'] -= 1
            send_result(key, edit=True, msg_obj=call.message)
        bot.answer_callback_query(call.id)
    elif call.data == "download":
        index = cache['index']
        selected = cache['results'][index]
        # طلب رابط التحميل يتم فقط عند الضغط على الزر
        old_result = old_download_api(selected.get('url', ''))
        if not old_result:
            bot.answer_callback_query(call.id, "فشل الحصول على رابط التحميل.")
            return
        cache['results'][index] = old_result
        info = old_result
        url = info.get('download', {}).get('audio')
        if not url:
            bot.answer_callback_query(call.id, "فشل الحصول على رابط التحميل.")
            return
        safe_title = re.sub(r'[^\w\-. ]', '', info.get("title", ""))[:30]
        filename = f"{safe_title}_{uuid.uuid4().hex[:8]}.mp3"
        try:
            bot.edit_message_caption(
                chat_id=chat_id,
                message_id=call.message.message_id,
                caption="جاري التحميل...",
                parse_mode="HTML"
            )
        except Exception as e:
            print(f"Edit message failed: {e}")
        filepath = downloadFile(url, filename)  # حجم الملف الافتراضي 5 ميجا
        if filepath == "too_large":
            bot.edit_message_caption(chat_id, call.message.message_id, caption="⚠️ الملف أكبر من 5 ميجا، لا يمكن تحميله.", parse_mode="HTML")
            return
        elif filepath:
            try:
                with open(filepath, "rb") as audio:
                    bot.send_document(chat_id, audio, caption=f"@{call.from_user.username or call.from_user.id} 🦋", reply_to_message_id=cache['reply_to'])
                bot.delete_message(chat_id, call.message.message_id)
            except Exception as e:
                bot.send_message(chat_id, f"حدث خطأ أثناء الإرسال: {e}")
            finally:
                os.remove(filepath)
        else:
            bot.edit_message_caption(chat_id=chat_id, message_id=call.message.message_id, caption="فشل التحميل، حاول مرة ثانية.", parse_mode="HTML")
        bot.answer_callback_query(call.id)

@bot.message_handler(func=lambda m: m.text and re.search(r'(https?://[^\s]+)', m.text) and not m.text.startswith("بحث"))
def direct_download_handler(message):
    # التعرف على مصدر الرابط وعرض الرسالة المناسبة
    url_in_message = re.search(r'(https?://[^\s]+)', message.text).group(1)
    lower_url = url_in_message.lower()
    if "instagram" in lower_url:
        load_text = "جار التحميل من انستغرام..."
    elif "tiktok" in lower_url:
        load_text = "جار التحميل من تيك توك..."
    elif "youtube" in lower_url or "youtu.be" in lower_url:
        load_text = "جار التحميل من يوتيوب..."
    elif "pinterest" in lower_url:
        load_text = "جار التحميل من بنترست..."
    elif "snapchat" in lower_url:
        load_text = "جار التحميل من سناب شات..."
    else:
        load_text = "جار التحميل..."

    loading_msg = bot.reply_to(message, load_text)
    try:
        response = requests.get(f"http://145.223.80.56:5003/get?q={url_in_message}", timeout=60)
        if response.status_code != 200:
            bot.edit_message_text("فشل التحميل، حاول مرة ثانية.", 
                                  chat_id=message.chat.id, 
                                  message_id=loading_msg.message_id)
            return
        data = response.json()
        download_link = data.get("Download link")
        if not download_link:
            bot.edit_message_text("فشل الحصول على رابط التحميل.", 
                                  chat_id=message.chat.id, 
                                  message_id=loading_msg.message_id)
            return
        ext = os.path.splitext(download_link)[1].lower()
        safe_title = "file"
        filename = f"{safe_title}_{uuid.uuid4().hex[:8]}{ext}"
        filepath = downloadFile(download_link, filename, check_size=True, max_size=15)
        if filepath == "too_large":
            bot.edit_message_text("⚠️ الملف أكبر من 15 ميجا.", 
                                  chat_id=message.chat.id, 
                                  message_id=loading_msg.message_id)
            return
        if filepath:
            caption = f"@{message.from_user.username or message.from_user.id} 🍓✨"
            if ext in [".mp4", ".mov", ".avi"]:
                with open(filepath, "rb") as video:
                    bot.send_video(message.chat.id, video, caption=caption, 
                                   reply_to_message_id=message.message_id)
            else:
                with open(filepath, "rb") as audio:
                    bot.send_document(message.chat.id, audio, caption=caption, 
                                      reply_to_message_id=message.message_id)
            os.remove(filepath)
            bot.delete_message(message.chat.id, loading_msg.message_id)
        else:
            bot.edit_message_text("فشل التحميل، حاول مرة ثانية.", 
                                  chat_id=message.chat.id, 
                                  message_id=loading_msg.message_id)
    except requests.exceptions.Timeout:
        bot.edit_message_text("انتهت المهلة أثناء التحميل، حاول مرة أخرى.", 
                              chat_id=message.chat.id, 
                              message_id=loading_msg.message_id)
    except Exception as e:
        bot.edit_message_text(f"حدث خطأ أثناء التحميل: {e}", 
                              chat_id=message.chat.id, 
                              message_id=loading_msg.message_id)

@bot.message_handler(func=lambda m: m.text and re.match(r"^(يوت|تحميل|اغنيه|اغنية) (.+)", m.text.strip()))
def quick_search_handler(message):
    query = message.text.split(" ", 1)[1].strip()
    loading = bot.reply_to(message, "جاري البحث وتحضير النتائج...")
    results = search_youtube(query)
    try:
        bot.delete_message(message.chat.id, loading.message_id)
    except Exception as e:
        print(f"Error deleting loading message: {e}")
    if not results:
        bot.reply_to(message, "ما لقيت نتائج 🥹")
        return

    limited_results = results[:5]
    # هنا نستخدم مفتاح عشوائي منفصل لكل طلب سريع (ليس بنفس أسلوب البحث العام)
    key = uuid.uuid4().hex[:8]
    search_cache[key] = {
        'results': limited_results,
        'reply_to': message.message_id,
        'user_id': message.from_user.id
    }

    markup = InlineKeyboardMarkup(row_width=1)
    buttons = []
    for i, res in enumerate(limited_results):
        title = res.get("title", "بدون عنوان")[:40]
        buttons.append(InlineKeyboardButton(f"{i+1}. {title}", callback_data=f"dl_{key}_{i}"))
    markup.add(*buttons)

    bot.send_message(message.chat.id, "اختر النتيجة التي تريد تحميلها:", reply_markup=markup, reply_to_message_id=message.message_id)

@bot.callback_query_handler(func=lambda call: call.data.startswith("dl_"))
def quick_download_handler(call):
    try:
        bot.answer_callback_query(call.id)
        _, key, index = call.data.split("_")
        cache = search_cache.get(key)
        if not cache:
            bot.send_message(call.message.chat.id, "انتهت الجلسة، أعد المحاولة.")
            return

        # التأكد من هوية المستخدم
        if call.from_user.id != cache.get('user_id'):
            bot.answer_callback_query(call.id, "البحث مو لك", show_alert=True)
            return

        index = int(index)
        selected = cache['results'][index]
        old_result = old_download_api(selected.get('url', ''))
        if not old_result:
            bot.send_message(call.message.chat.id, "فشل في التحميل، حاول مرة ثانية.")
            return

        url = old_result.get('download', {}).get('audio')
        if not url:
            bot.send_message(call.message.chat.id, "لم يتم العثور على رابط مباشر.")
            return

        safe_title = re.sub(r'[^\w\-. ]', '', old_result.get("title", ""))[:30]
        filename = f"{safe_title}_{uuid.uuid4().hex[:8]}.mp3"
        loading_msg = bot.send_message(call.message.chat.id, "جاري التحميل...")

        filepath = downloadFile(url, filename)
        if filepath == "too_large":
            bot.edit_message_text("⚠️ الملف أكبر من 5 ميجا، لا يمكن تحميله.", chat_id=call.message.chat.id, message_id=call.message.message_id)
            return
        elif filepath:
            with open(filepath, "rb") as audio:
                bot.send_document(call.message.chat.id, audio, caption=f"@{call.from_user.username or call.from_user.id} 🍓✨", reply_to_message_id=cache['reply_to'])
            bot.delete_message(call.message.chat.id, call.message.message_id)
            os.remove(filepath)
        else:
            bot.edit_message_text("فشل التحميل، حاول مرة ثانية.", chat_id=call.message.chat.id, message_id=call.message.message_id)

    except Exception as e:
        print(f"[Callback Error]: {e}")
        bot.send_message(call.message.chat.id, "حدث خطأ أثناء التحميل.")
# --------------------------
# إنشاء الصورة عبر "حلا اعملي صورة + نص"

import requests
import re
from deep_translator import GoogleTranslator

# الدوال المساعدة للتأكد من الاشتراك
def is_subscribed(user_id):
    # هنا يمكن إضافة منطق التحقق من الاشتراك
    return True  # افتراضياً، المستخدم مشترك

def send_subscription_message(chat_id):
    # إرسال رسالة تطلب الاشتراك في القناة
    bot.send_message(chat_id, "من فضلك اشترك في القناة للحصول على هذه الخدمة.")

@bot.message_handler(func=lambda message: message.text and message.text.lower().startswith("حلا اعملي صوره"))
def generate_logo(message):
    # استخراج النص المرافق للأمر
    description = message.text[len("حلا اعملي صوره"):].strip()

    if not description:
        bot.reply_to(message, "😕 من فضلك أرسل وصف الصورة بعد الأمر\nمثلاً: حلا اعملي صوره مدينة حلوة")
        return

    # التحقق من اشتراك المستخدم
    if not is_subscribed(message.from_user.id):
        send_subscription_message(message)
        return

    bot.send_chat_action(message.chat.id, 'typing')
    
    # إرسال رسالة انتظار وتخزينها لحذفها لاحقاً
    waiting_msg = bot.reply_to(message, "استنى شويه، بترجم وبعمل لك الصورة...")
    
    try:
        # ترجمة النص (بما في ذلك النصوص التي تحتوي على الصفات) للإنجليزية
        prompt_text = GoogleTranslator(source='auto', target='en').translate(description)
        print(f"الوصف المترجم: {prompt_text}")
    except Exception as e:
        bot.reply_to(message, f"حدث خطأ أثناء الترجمة: {str(e)}")
        bot.delete_message(message.chat.id, waiting_msg.message_id)
        return

    try:
        # إرسال النص للـ API
        api_url = f"https://dev-pycodz-blackbox.pantheonsite.io/DEvZ44d/imger.php?img={requests.utils.quote(prompt_text)}"
        response = requests.get(api_url)

        if response.status_code != 200:
            bot.reply_to(message, "مع الأسف، ما قدرت أعمل الصورة.")
            bot.delete_message(message.chat.id, waiting_msg.message_id)
            return

        # إعداد التسمية التوضيحية مع إضافة معرف المستخدم (اسم المستخدم أو الاسم الأول)
        if message.from_user.username:
            requester = f"@{message.from_user.username}"
        else:
            requester = message.from_user.first_name

        caption = f"تفضل يروحي ✨\nRequested by: {requester}"

        # إرسال الصورة كرد على رسالة المستخدم
        if response.content:
            bot.send_photo(message.chat.id, response.content, caption=caption, reply_to_message_id=message.message_id)
        else:
            bot.reply_to(message, "عذراً، لم أتمكن من إنشاء الصورة بناءً على الوصف.")
    except Exception as e:
        bot.reply_to(message, f"حدث خطأ أثناء تنفيذ الطلب: {str(e)}")
    finally:
        # حذف رسالة الانتظار
        bot.delete_message(message.chat.id, waiting_msg.message_id)

# --------------------------
# المعالجة العامة لجميع الرسائل (مثال على أوامر "id" والأوامر الخاصة بالمجموعات والدردشات الخاصة)
WELCOME_IMAGE = "welcome.jpg"  # صورة الترحيب إن وُجدت
user_msg_count = {}    # عداد رسائل المستخدمين
active_chats = {}      # حالة تفعيل البوت في المجموعات (chat_id: True/False)

stats = {"active_groups": 0, "groups": 0}  # إحصائيات بسيطة

# ملف لتخزين بيانات تفعيل المجموعات مع بيانات المُفعل
ACTIVATED_FILE = "activated_groups.json"

# محاولة تحميل بيانات التفعيل عند بدء تشغيل البوت
if os.path.exists(ACTIVATED_FILE):
    with open(ACTIVATED_FILE, "r", encoding="utf-8") as f:
        activated_groups = json.load(f)
else:
    activated_groups = {}  # الصيغة: { "chat_id": {"activated_by": user_id, "username": "@username"} }

def save_activated_groups():
    with open(ACTIVATED_FILE, "w", encoding="utf-8") as f:
        json.dump(activated_groups, f, ensure_ascii=False, indent=2)

# دوال مساعدة (مثال: التحقق من الاشتراك)
def is_subscribed(user_id):
    # هنا يتم التحقق مما إذا كان المستخدم مشترك بالقناة المطلوبة
    return True

def send_subscription_message(chat_id):
    bot.send_message(chat_id, "يجب الاشتراك بالقناة أولا!")

def add_new_user(user_id):
    # إضافة المستخدم لقاعدة البيانات الخاصة بالبوت إن وُجدت
    pass

def format_text(text):
    # تنسيق النص كما تشاء
    return text

def get_random_activation_reply():
    replies = ["تم تفعيل حلا بنجاح!", "حلا شغالة هلق في المجموعة!"]
    return random.choice(replies)

def get_random_deactivation_reply():
    replies = ["تم إيقاف حلا!", "حلا توقفت، عسى نرجعها لاحقاً!"]
    return random.choice(replies)

# متغيرات الحالة
activated_groups = {}
active_chats = {}
stats = {"active_groups": 0, "groups": 0}
user_msg_count = {}
WELCOME_IMAGE = "welcome.jpg"  # تأكد من وجود الصورة أو حدث اسمها

# دوال حفظ واسترجاع بيانات التفعيل
def save_activated_groups():
    with open("activated_groups.json", "w", encoding="utf-8") as f:
        json.dump(activated_groups, f, ensure_ascii=False, indent=4)

def load_activated_groups():
    global activated_groups, active_chats
    try:
        with open("activated_groups.json", "r", encoding="utf-8") as f:
            activated_groups = json.load(f)
            active_chats = {chat_id: True for chat_id in activated_groups.keys()}
    except FileNotFoundError:
        activated_groups = {}
        active_chats = {}

# إعداد المتغيرات الأساسية
BOT_USERNAME = "ChatGPTdarkbot"  # عدلها حسب اسم بوتك
WELCOME_IMAGE = "welcome.jpg"

# متغيرات النظام والإحصائيات
user_msg_count = {}
active_chats = {}
stats = {"active_groups": 0, "groups": 0}
activated_groups = {}

# تحميل بيانات التفعيل عند بدء التشغيل
def load_activated_groups():
    # يمكنك هنا قراءة البيانات من ملف أو قاعدة بيانات إذا لزم الأمر
    pass

load_activated_groups()

# دالة للتأكد من اشتراك المستخدم (تعدل حسب منطقك)
def is_subscribed(user_id):
    # هنا حط منطق التحقق من الاشتراك
    return True

# دالة لإرسال رسالة الاشتراك
def send_subscription_message(chat_id):
    bot.send_message(chat_id, "يرجى الاشتراك بالقناة لتتمكن من استخدام البوت.")

# دالة لإضافة مستخدم جديد
def add_new_user(user_id):
    # هنا يمكنك حفظ بيانات المستخدمين في ملف أو قاعدة بيانات
    pass

# دالة لتنسيق النص (تعدل حسب حاجتك)
def format_text(text):
    return text.strip()

# دالة لإرجاع رد عشوائي عند التفعيل
def get_random_activation_reply():
    replies = ["تم التفعيل", "حالا مفعلة", "حلا اشتغلت", "أصبحت نشطة"]
    return random.choice(replies)

# دالة لإرجاع رد عشوائي عند الإيقاف
def get_random_deactivation_reply():
    replies = ["تم الإيقاف", "حلا توقفت", "البوت خرج", "أصبحت غير نشطة"]
    return random.choice(replies)

# دالة لإزالة الإيموجيات من النص
def remove_emojis(input_text):
    emoji_pattern = re.compile("[" 
        u"\U0001F600-\U0001F64F"  # الوجوه التعبيرية
        u"\U0001F300-\U0001F5FF"  # الرموز والصور
        u"\U0001F680-\U0001F6FF"  # وسائل النقل والخرائط
        u"\U0001F1E0-\U0001F1FF"  # أعلام الدول
        "]+", flags=re.UNICODE)
    return emoji_pattern.sub(r'', input_text)

# ========================================
# الميزة الجديدة: "حلا ضيفي لنظامك"
# ========================================
@bot.message_handler(func=lambda message: message.text and message.text.startswith("حلا ضيفي لنظامك"))
def handle_add_system(message):
    # التحقق من أن المستخدم هو الادمن فقط
    if message.from_user.id != ADMIN_ID:
        bot.reply_to(message, "انت مش المطور\nما الك حق تطلب مميزات لحلا\nحلا حلوه بدون مميزات جديده")
        return

    original_text = message.text
    added_text = original_text[len("حلا ضيفي لنظامك"):].strip()
    request_text = added_text + " لا تكتب شيئ فقط ارسل السكربت ويجب ان يكون يعمل عبر telebot + bot bolling() بدون main او غيره يجب ان يكون بايثون + لا تضع تعريف توكن او ما شابه لان سيتم اضافه الميزه الى كود بوت تلقائيا + رسائل الكود اجعلهم باللهجه الفلسطينيه كفتاه تتحدث مع شخص + اهم شيئ لا تكتب شيئ او تضع امثله فقط نفذ الطلب وارسله بدون اي كلمه اضافيه +"
    
    # استدعاء API أصبح الآن لن يتم طلبه إذا لم يكن الادمن
    api_url = f"https://dev-darkcre.pantheonsite.io/API/DARKBLACKGPT.php?text={requests.utils.quote(request_text)}"
    try:
        api_response = requests.get(api_url, timeout=60)
        if api_response.status_code != 200:
            bot.reply_to(message, "رسالتك طويلة\nاسف ما بقدر ارد عليك")
            return
        response_text = api_response.text.strip()
        try:
            response_json = json.loads(response_text)
            response_text = response_json.get("response", "")
        except Exception:
            pass
        # حذف كلمة "python" والنقاط الثلاثة ```
        response_text = response_text.replace("python", "").replace("```", "")
    except Exception as e:
        bot.reply_to(message, f"خطأ: {str(e)}")
        return

    # حفظ السكربت المضاف
    file_name = "feature.py"
    with open(file_name, "w", encoding="utf-8") as f:
        f.write(response_text)

    markup = telebot.types.InlineKeyboardMarkup()
    btn_check = telebot.types.InlineKeyboardButton("معرفه الاخطاء", callback_data="check_errors")
    btn_activate = telebot.types.InlineKeyboardButton("تفعيل النظام", callback_data="activate_system")
    markup.add(btn_check, btn_activate)

    bot.send_document(ADMIN_ID, open(file_name, "rb"), caption="تفضل يروحي", reply_markup=markup)
    os.remove(file_name)

    if message.chat.type in ["group", "supergroup"]:
        markup2 = telebot.types.InlineKeyboardMarkup()
        button = telebot.types.InlineKeyboardButton("تفعيل النظام", url=f"https://t.me/{BOT_USERNAME}")
        markup2.add(button)
        bot.send_message(message.chat.id, "تم اضافه الميزه الى النظام : @sii_3", reply_markup=markup2)

@bot.callback_query_handler(func=lambda call: call.data in ["check_errors", "activate_system"])
def handle_callback(call):
    if call.data == "activate_system":
        if call.from_user.id != ADMIN_ID:
            bot.answer_callback_query(call.id, "انت مش المطور", show_alert=True)
            return
        handle_activate_system(call)
    elif call.data == "check_errors":
        handle_check_errors(call)

def handle_check_errors(call):
    if call.message.document:
        file_id = call.message.document.file_id
        file_info = bot.get_file(file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        temp_file = "temp_feature.py"
        with open(temp_file, "wb") as f:
            f.write(downloaded_file)
        with open(temp_file, "r", encoding="utf-8") as f:
            script_text = f.read()
        api_url = "https://dev-darkcre.pantheonsite.io/API/DARKBLACKGPT.php?text="
        check_request = "هل هناك ايه اخطاء في هذا السكربت اصلحها + لا تكتب اي شيئ ففقط اصلحها + اذا لم يكن هناك ايه اخطاء اكتب كلمه واحده بان لا يوجد اخطاء"
        full_url = api_url + requests.utils.quote(check_request + "\n" + script_text)
        try:
            api_response = requests.get(full_url, timeout=60)
            response_text = api_response.text.strip()
            try:
                response_json = json.loads(response_text)
                response_text = response_json.get("response", "")
            except Exception:
                pass
            if "لا يوجد اخطاء" in response_text:
                bot.reply_to(call.message, "لا يوجد اخطاء في السكربت")
            else:
                corrected_file = "fixed_feature.py"
                with open(corrected_file, "w", encoding="utf-8") as f:
                    f.write(response_text)
                bot.send_document(ADMIN_ID, open(corrected_file, "rb"), caption="تم اصلاح الاخطاء")
                os.remove(corrected_file)
        except Exception as e:
            bot.reply_to(call.message, f"اسفه ما قدرت ابرمجه {str(e)}")
        os.remove(temp_file)

def handle_activate_system(call):
    if call.from_user.id != ADMIN_ID:
        bot.answer_callback_query(call.id, "اسفه انت مش المطور ما الك حق تضيف ميزات للنظام", show_alert=True)
        return
    if call.message.document:
        file_id = call.message.document.file_id
        file_info = bot.get_file(file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        feature_code = downloaded_file.decode("utf-8")
        main_script = "hala.py"  # اسم سكربت البوت الأساسي
        backup_script = "bot_main_backup.py"
        try:
            with open(main_script, "r", encoding="utf-8") as f:
                bot_code = f.read()
            # الاحتفاظ بنسخة احتياطية
            with open(backup_script, "w", encoding="utf-8") as f:
                f.write(bot_code)
            # دمج السكربت الجديد مع البوت الأساسي بعد التوكن
            token_line_index = bot_code.find("TOKEN =")
            bot_code_lines = bot_code.split("\n")
            new_code = "\n".join(bot_code_lines[:token_line_index + 1]) + "\n" + feature_code + "\n" + "\n".join(bot_code_lines[token_line_index + 1:])
            with open(main_script, "w", encoding="utf-8") as f:
                f.write(new_code)
            bot.reply_to(call.message, "تم اضافه الميزه الى النظام : @sii_3")
        except Exception as e:
            bot.reply_to(call.message, f"اسفه ما قدرت ابرمجه: {str(e)}")

# ========================================
# نهاية ميزة "حلا ضيفي لنظامك"
# ========================================

# تعريف متغيرات التخزين
activated_groups = {}  # بيانات المجموعات المفعلة
active_chats = {}      # حالة تفعيل المجموعات
stats = {
    "active_groups": 0,
    "groups": 0
}
user_msg_count = {}

# دالة لحفظ بيانات المجموعات المفعلة في ملف JSON
def save_activated_groups():
    with open("activated_groups.json", "w", encoding="utf-8") as f:
        json.dump(activated_groups, f, ensure_ascii=False, indent=4)

# دالة لتحميل بيانات المجموعات المفعلة من ملف JSON (إذا كانت موجودة)
def load_activated_groups():
    global activated_groups
    if os.path.exists("activated_groups.json"):
        with open("activated_groups.json", "r", encoding="utf-8") as f:
            activated_groups = json.load(f)

# تأكد من تحميل بيانات التفعيل عند بدء التشغيل
load_activated_groups()

# متغيرات عامة للتخزين والإحصائيات
user_msg_count = {}
active_chats = {}
stats = {"active_groups": 0, "groups": 0}
activated_groups = {}

WELCOME_IMAGE = "welcome.jpg"  # صورة الترحيب إن وُجدت

# دوال مساعدة (يمكن تعديلها حسب الحاجة)
def is_subscribed(user_id):
    # تحقق من الاشتراك، هنا دالة تجريبية تُعيد True دائمًا
    return True

def send_subscription_message(chat_id):
    bot.send_message(chat_id, "فضلاً اشترك بالقناة لتتمكن من الاستخدام!")

def save_activated_groups():
    with open("activated_groups.json", "w", encoding="utf-8") as f:
        json.dump(activated_groups, f, ensure_ascii=False, indent=4)

def load_activated_groups():
    global activated_groups
    if os.path.exists("activated_groups.json"):
        with open("activated_groups.json", "r", encoding="utf-8") as f:
            activated_groups = json.load(f)

def get_random_activation_reply():
    return "تم تفعيل حلا"

def get_random_deactivation_reply():
    return "تم إيقاف حلا"

def format_text(text):
    return text  # يمكنك تعديلها لتنسيق النص حسب الحاجة

def remove_emojis(text):
    # دالة تجريبية لإزالة الإيموجي (يمكن تطويرها)
    return text

def add_new_user(user_id):
    # دالة لإضافة مستخدم جديد (يمكنك تعديلها)
    pass

# تحميل بيانات التفعيل عند بدء التشغيل
load_activated_groups()

# قائمة الدول والتوقيتات (لأمر معرفة الوقت)
countries = {
    "مصر": "Africa/Cairo",
    "السعودية": "Asia/Riyadh",
    "فلسطين": "Asia/Gaza",
    "الأردن": "Asia/Amman",
    "لبنان": "Asia/Beirut",
    "سوريا": "Asia/Damascus",
    "العراق": "Asia/Baghdad",
    "الإمارات": "Asia/Dubai",
    "الكويت": "Asia/Kuwait",
    "قطر": "Asia/Qatar",
    "البحرين": "Asia/Bahrain",
    "عُمان": "Asia/Muscat",
    "الجزائر": "Africa/Algiers",
    "المغرب": "Africa/Casablanca",
    "تونس": "Africa/Tunis",
    "ليبيا": "Africa/Tripoli",
    "السودان": "Africa/Khartoum",
    "اليمن": "Asia/Aden"
}

def get_time(country_name):
    """ترجع الوقت الحالي في الدولة المطلوبة"""
    if country_name in countries:
        tz = pytz.timezone(countries[country_name])
        now = datetime.datetime.utcnow().replace(tzinfo=pytz.utc).astimezone(tz)
        return f"يروحي هسه في {country_name}\nالساعه  {now.strftime('%I:%M %p')}"
    else:
        return "✋ ما بعرف توقيت هالدولة، تأكد من الاسم!"

import os, json, time, random, re, datetime, pytz, requests, sys
from telebot import types

# التأكد من وجود مجلد data
if not os.path.exists("data"):
    os.mkdir("data")

# مسارات الملفات داخل مجلد data
ACTIVATED_GROUPS_FILE = os.path.join("data", "activated_groups.json")
SUBSCRIBED_USERS_FILE = os.path.join("data", "subscribed_users.json")
STATS_FILE = os.path.join("data", "stats.json")
WELCOME_MEDIA_FILE = os.path.join("data", "welcome_media.json")
SETTINGS_FILE = os.path.join("data", "settings.json")

# متغيرات عامة للتخزين والإحصائيات
user_msg_count = {}
active_chats = {}      # لتخزين حالة التفعيل المؤقتة للمجموعات
stats = {"active_groups": 0, "groups": 0, "users": 0}
activated_groups = {}  # لتخزين بيانات المجموعات المُفعلة (تتضمن معلومات مثل من فَعّلها)

WELCOME_IMAGE = "welcome.jpg"  # صورة الترحيب إن وُجدت

# إعداد وسائط الترحيب الافتراضية
welcome_media = {
    "type": "photo",         # يمكن أن يكون "photo" أو "video" أو "animation"
    "file_path": os.path.join("data", WELCOME_IMAGE)
}

# إعدادات البوت؛ تمت إضافة مفتاح bot_gender لتحديد جنس البوت (default: "أنثى")
settings = {
    "start_message": "مرحبًا، انا {bot_name}! 🤗\nبنت ذكية وتساعدك وتحكي معك\nضيفني لمجموعتك واكتب تفعيل {bot_name}\nيلا شو بتستنا؟",
    "bot_name": "حلا",
    "bot_gender": "أنثى"  # أو "ذكر"
}

# دوال حفظ واسترجاع البيانات
def save_activated_groups():
    with open(ACTIVATED_GROUPS_FILE, "w", encoding="utf-8") as f:
        json.dump(activated_groups, f, ensure_ascii=False, indent=4)

def load_activated_groups():
    global activated_groups, active_chats, stats
    if os.path.exists(ACTIVATED_GROUPS_FILE):
        try:
            loaded = json.load(open(ACTIVATED_GROUPS_FILE, "r", encoding="utf-8"))
            activated_groups.update(loaded)
            for chat_id in activated_groups:
                active_chats[chat_id] = True
                stats["active_groups"] += 1
                stats["groups"] += 1
        except Exception:
            pass

def save_subscribed_users():
    with open(SUBSCRIBED_USERS_FILE, "w", encoding="utf-8") as f:
        json.dump(subscribed_users, f, ensure_ascii=False, indent=4)

def load_subscribed_users():
    global subscribed_users, stats
    if os.path.exists(SUBSCRIBED_USERS_FILE):
        try:
            subscribed_users.update(json.load(open(SUBSCRIBED_USERS_FILE, "r", encoding="utf-8")))
            stats["users"] = len(subscribed_users)
        except Exception:
            subscribed_users.clear()
    else:
        subscribed_users.clear()

def save_stats():
    with open(STATS_FILE, "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=4)

def load_stats():
    global stats
    if os.path.exists(STATS_FILE):
        try:
            stats.update(json.load(open(STATS_FILE, "r", encoding="utf-8")))
        except Exception:
            pass

def save_welcome_media():
    with open(WELCOME_MEDIA_FILE, "w", encoding="utf-8") as f:
        json.dump(welcome_media, f, ensure_ascii=False, indent=4)

def load_welcome_media():
    global welcome_media
    if os.path.exists(WELCOME_MEDIA_FILE):
        try:
            welcome_media.update(json.load(open(WELCOME_MEDIA_FILE, "r", encoding="utf-8")))
        except Exception:
            pass

def save_settings():
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, ensure_ascii=False, indent=4)

def load_settings():
    global settings
    if os.path.exists(SETTINGS_FILE):
        try:
            settings.update(json.load(open(SETTINGS_FILE, "r", encoding="utf-8")))
        except Exception:
            pass

# تحميل البيانات عند بدء التشغيل
load_activated_groups()
subscribed_users = {}
load_subscribed_users()
load_stats()
load_welcome_media()
load_settings()

# التأكد من وجود مجلدات الميمات داخل مجلد meme
def ensure_meme_directories():
    base_folder = "meme"
    subfolders = ["memephoto", "memevideo"]
    for sub in subfolders:
        os.makedirs(os.path.join(base_folder, sub), exist_ok=True)

ensure_meme_directories()

# قائمة الدول والتوقيتات (لأمر معرفة الوقت)
countries = {
    "مصر": "Africa/Cairo",
    "السعودية": "Asia/Riyadh",
    "فلسطين": "Asia/Gaza",
    "الاردن": "Asia/Amman",
    "لبنان": "Asia/Beirut",
    "سوريا": "Asia/Damascus",
    "العراق": "Asia/Baghdad",
    "الامارات": "Asia/Dubai",
    "الكويت": "Asia/Kuwait",
    "قطر": "Asia/Qatar",
    "البحرين": "Asia/Bahrain",
    "عمان": "Asia/Muscat",
    "الجزائر": "Africa/Algiers",
    "المغرب": "Africa/Casablanca",
    "تونس": "Africa/Tunis",
    "ليبيا": "Africa/Tripoli",
    "السودان": "Africa/Khartoum",
    "اليمن": "Asia/Aden"
}

def get_time(country_name):
    if country_name in countries:
        tz = pytz.timezone(countries[country_name])
        now = datetime.datetime.utcnow().replace(tzinfo=pytz.utc).astimezone(tz)
        return f"هسا في {country_name}\nالساعة - {now.strftime('%I:%M %p')}"
    else:
        return "ما بعرف توقيت هالدولة\n تأكد من الاسم"

# إعدادات القناة ومعرف الأدمن وغيرها
CHANNEL_USERNAME = "HalaGPT"

# دوال إضافية
def get_random_activation_reply():
    replies = ["تم تفعيل {bot_name}", "{bot_name} الآن شغالة"]
    return random.choice(replies).replace("{bot_name}", settings["bot_name"])

def get_random_deactivation_reply():
    replies = ["تم إيقاف {bot_name}", "{bot_name} توقفت"]
    return random.choice(replies).replace("{bot_name}", settings["bot_name"])

def format_text(text):
    return text

def remove_emojis(text):
    return text

def add_new_user(user_id):
    # منطق تسجيل المستخدمين الجدد إن وُجد
    pass

def text_to_voice_fallback(text, lang='ar'):
    try:
        from gtts import gTTS
        tts = gTTS(text, lang=lang)
        fallback_file = "fallback_voice.mp3"
        tts.save(fallback_file)
        return fallback_file
    except Exception as e:
        print(f"Error in fallback TTS: {e}")
        return None

# متغير لتخزين حالة انتظار كل chat_id لنوع الوسائط المطلوبة
pending_media = {}

@bot.message_handler(commands=['control'])
def control_panel(message):
    if message.from_user.id != ADMIN_ID:
        return
    markup = types.InlineKeyboardMarkup(row_width=2)
    change_media_btn = types.InlineKeyboardButton("تغيير وسائط الترحيب", callback_data="change_welcome_media")
    change_start_msg_btn = types.InlineKeyboardButton("تغيير رسالة /start", callback_data="change_start_msg")
    change_bot_name_btn = types.InlineKeyboardButton("تغيير اسم البوت", callback_data="change_bot_name")
    stats_btn = types.InlineKeyboardButton("عرض الإحصائيات", callback_data="view_stats")
    restart_btn = types.InlineKeyboardButton("إعادة تشغيل البوت", callback_data="restart_bot")
    extra_btn = types.InlineKeyboardButton("ميزات إضافية", callback_data="extra_features")
    markup.add(change_media_btn, change_start_msg_btn, change_bot_name_btn, stats_btn, restart_btn, extra_btn)
    bot.reply_to(message, "لوحة تحكم الأدمن:", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data in [
    "view_stats", "change_welcome_media", "change_start_msg", "change_bot_name",
    "restart_bot", "extra_features", "refresh_stats", "list_users", "add_meme",
    "add_meme_photo", "add_meme_video", "add_meme_sticker"
])
def control_callbacks(call):
    if call.from_user.id != ADMIN_ID:
        bot.answer_callback_query(call.id, "هذه الوظيفة للأدمن فقط!", show_alert=True)
        return

    chat_id = call.message.chat.id

    if call.data == "view_stats":
        stats_text = (f"عدد المستخدمين: {stats.get('users', 0)}\n"
                      f"عدد المجموعات: {stats.get('groups', 0)}\n"
                      f"المجموعات المفعلة: {stats.get('active_groups', 0)}")
        bot.answer_callback_query(call.id)
        bot.send_message(chat_id, stats_text)
    elif call.data == "change_welcome_media":
        msg = bot.send_message(chat_id, "أرسل لي الملف الجديد للترحيب (صورة أو فيديو أو صورة متحركة).")
        bot.register_next_step_handler(msg, process_welcome_media)
    elif call.data == "change_start_msg":
        msg = bot.send_message(chat_id,
                               "أرسل لي رسالة /start الجديدة.\nيمكنك استخدام {bot_name} ليُستبدل باسم البوت الحالي.")
        bot.register_next_step_handler(msg, process_start_msg)
    elif call.data == "change_bot_name":
        msg = bot.send_message(chat_id, "أرسل لي الاسم الجديد للبوت:")
        bot.register_next_step_handler(msg, process_bot_name)
    elif call.data == "restart_bot":
        bot.send_message(chat_id, "جاري إعادة تشغيل البوت...")
        save_activated_groups()
        save_settings()
        os.execv(sys.executable, ['python'] + sys.argv)
    elif call.data == "extra_features":
        extra_markup = types.InlineKeyboardMarkup(row_width=1)
        extra_markup.add(types.InlineKeyboardButton("إضافة ميمات", callback_data="add_meme"))
        bot.edit_message_text("اختر من الميزات الإضافية:", chat_id, call.message.message_id, reply_markup=extra_markup)
    elif call.data == "add_meme":
        meme_markup = types.InlineKeyboardMarkup(row_width=1)
        meme_markup.add(types.InlineKeyboardButton("إضافة ميم صورة", callback_data="add_meme_photo"))
        meme_markup.add(types.InlineKeyboardButton("إضافة ميم فيديو", callback_data="add_meme_video"))
        meme_markup.add(types.InlineKeyboardButton("إضافة ميم ملصق", callback_data="add_meme_sticker"))
        bot.edit_message_text("اختر نوع الميم الذي تريد إضافته:", chat_id, call.message.message_id, reply_markup=meme_markup)
    elif call.data == "refresh_stats":
        load_stats()
        bot.answer_callback_query(call.id, "تم تحديث الإحصائيات!")
    elif call.data == "list_users":
        users_list = "\n".join(subscribed_users.keys())
        bot.send_message(chat_id, f"المستخدمين:\n{users_list}")
    elif call.data == "add_meme_photo":
        pending_media[chat_id] = "photo"
        msg = bot.send_message(chat_id, "أرسل لي صورة الميم التي تريد إضافتها:")
        bot.register_next_step_handler(msg, process_meme_photo)
    elif call.data == "add_meme_video":
        pending_media[chat_id] = "video"
        msg = bot.send_message(chat_id, "أرسل لي فيديو الميم الذي تريد إضافته:")
        bot.register_next_step_handler(msg, process_meme_video)
    elif call.data == "add_meme_sticker":
        pending_media[chat_id] = "sticker"
        msg = bot.send_message(chat_id, "أرسل لي ملصق الميم الذي تريد إضافته:")
        bot.register_next_step_handler(msg, process_meme_sticker)

meme_photos = []
meme_videos = []
meme_stickers = []  # قائمة لتخزين معرفات الملصقات

def save_memes():
    # حفظ الميمات في ملف JSON مع الصور والفيديوهات والملصقات
    with open('memes.json', 'w') as f:
        json.dump({
            "photos": meme_photos,
            "videos": meme_videos,
            "stickers": meme_stickers
        }, f)

def process_meme_photo(message):
    chat_id = message.chat.id
    if pending_media.get(chat_id) != "photo":
        return
    if message.content_type != 'photo':
        msg = bot.send_message(chat_id, "يجب أن ترسل صورة فقط! حاول مرة أخرى.")
        bot.register_next_step_handler(msg, process_meme_photo)
        return

    file_id = message.photo[-1].file_id
    file_info = bot.get_file(file_id)
    file_url = f"https://api.telegram.org/file/bot{TOKEN}/{file_info.file_path}"

    response = requests.get(file_url)
    if response.status_code == 200:
        folder = os.path.join("meme", "memephoto")
        os.makedirs(folder, exist_ok=True)
        photo_filename = os.path.join(folder, f"{file_id}.jpg")
        with open(photo_filename, 'wb') as f:
            f.write(response.content)
        meme_photos.append(photo_filename)
        save_memes()
        bot.send_message(chat_id, f"تم إضافة صورة الميم بنجاح!\nتم حفظها في:\n`{photo_filename}`", parse_mode="Markdown")
    else:
        bot.send_message(chat_id, "حدث خطأ أثناء تحميل الصورة.")
    pending_media.pop(chat_id, None)

@bot.message_handler(content_types=['sticker'])
def process_meme_sticker(message):
    chat_id = message.chat.id
    if pending_media.get(chat_id) != "sticker":
        return
    if message.content_type != 'sticker':
        msg = bot.send_message(chat_id, "يجب أن ترسل ملصق فقط! حاول مرة أخرى.")
        bot.register_next_step_handler(msg, process_meme_sticker)
        return

    # بدلاً من تنزيل الملصق، نقوم بحفظ معرف الملصق فقط
    sticker_id = message.sticker.file_id
    meme_stickers.append(sticker_id)
    save_memes()
    bot.send_message(chat_id, f"تم حفظ ملصق الميم بنجاح!\nمعرف الملصق: `{sticker_id}`", parse_mode="Markdown")
    pending_media.pop(chat_id, None)

def process_meme_video(message):
    chat_id = message.chat.id
    if pending_media.get(chat_id) != "video":
        return
    if message.content_type != 'video':
        msg = bot.send_message(chat_id, "يجب أن ترسل فيديو فقط! حاول مرة أخرى.")
        bot.register_next_step_handler(msg, process_meme_video)
        return

    file_id = message.video.file_id
    file_info = bot.get_file(file_id)
    file_url = f"https://api.telegram.org/file/bot{TOKEN}/{file_info.file_path}"

    response = requests.get(file_url)
    if response.status_code == 200:
        folder = os.path.join("meme", "memevideo")
        os.makedirs(folder, exist_ok=True)
        video_filename = os.path.join(folder, f"{file_id}.mp4")
        with open(video_filename, 'wb') as f:
            f.write(response.content)
        meme_videos.append(video_filename)
        save_memes()
        bot.send_message(chat_id, f"تم إضافة فيديو الميم بنجاح!\nتم حفظه في:\n`{video_filename}`", parse_mode="Markdown")
    else:
        bot.send_message(chat_id, "حدث خطأ أثناء تحميل الفيديو.")
    pending_media.pop(chat_id, None)

# ============================
# دوال معالجة تغيير وسائط الترحيب /start
# ============================
def process_welcome_media(message):
    global welcome_media
    if message.content_type in ["photo", "video", "animation"]:
        file_id = None
        if message.content_type == "photo":
            file_id = message.photo[-1].file_id
            welcome_media["type"] = "photo"
        elif message.content_type == "video":
            file_id = message.video.file_id
            welcome_media["type"] = "video"
        elif message.content_type == "animation":
            file_id = message.animation.file_id
            welcome_media["type"] = "animation"
        file_info = bot.get_file(file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        if welcome_media["type"] == "photo":
            filename = os.path.join("data", "welcome_image.jpg")
        elif welcome_media["type"] == "video":
            filename = os.path.join("data", "welcome_image.mp4")
        else:
            filename = os.path.join("data", "welcome_image.gif")
        with open(filename, "wb") as new_file:
            new_file.write(downloaded_file)
        welcome_media["file_path"] = filename
        save_welcome_media()
        bot.reply_to(message, "تم تحديث وسائط الترحيب بنجاح.")
    else:
        bot.reply_to(message, "يرجى إرسال ملف وسائط صحيح (صورة أو فيديو أو صورة متحركة).")

def process_start_msg(message):
    global settings
    new_msg = message.text.strip()
    if new_msg:
        settings["start_message"] = new_msg
        save_settings()
        bot.reply_to(message, "تم تحديث رسالة /start بنجاح.")
    else:
        bot.reply_to(message, "نص الرسالة فارغ. لم يتم التحديث.")

def process_bot_name(message):
    global settings
    new_name = message.text.strip()
    if new_name:
        settings["bot_name"] = new_name
        save_settings()
        gender_markup = types.InlineKeyboardMarkup(row_width=2)
        gender_markup.add(
            types.InlineKeyboardButton("ذكر", callback_data="set_gender_male"),
            types.InlineKeyboardButton("أنثى", callback_data="set_gender_female")
        )
        bot.send_message(message.chat.id, "هل البوت ذكر أم أنثى؟", reply_markup=gender_markup)
    else:
        bot.reply_to(message, "النص فارغ. لم يتم التحديث.")

@bot.callback_query_handler(func=lambda call: call.data in ["set_gender_male", "set_gender_female"])
def set_gender_callback(call):
    if call.from_user.id != ADMIN_ID:
        bot.answer_callback_query(call.id, "هذه الوظيفة للأدمن فقط!", show_alert=True)
        return
    if call.data == "set_gender_male":
        settings["bot_gender"] = "ذكر"
        settings["start_message"] = settings["start_message"].replace("بنت", "ولد")
        bot.edit_message_text("تم تعيين جنس البوت إلى ذكر وتحديث رسالة الترحيب accordingly.", call.message.chat.id, call.message.message_id)
    else:
        settings["bot_gender"] = "أنثى"
        settings["start_message"] = settings["start_message"].replace("ولد", "بنت")
        bot.edit_message_text("تم تعيين جنس البوت إلى أنثى.", call.message.chat.id, call.message.message_id)
    save_settings()

# ============================
# دوال الاشتراك
# ============================
def add_subscribed_user(user_id):
    subscribed_users[str(user_id)] = True
    save_subscribed_users()

def send_subscription_message(message):
    markup = types.InlineKeyboardMarkup()
    subscribe_button = types.InlineKeyboardButton("اشترك في القناة", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")
    check_button = types.InlineKeyboardButton("تحقق من الاشتراك", callback_data="check_subscription")
    markup.add(subscribe_button, check_button)
    bot.reply_to(
        message,
        f"انت لست مشترك في قناتي {CHANNEL_USERNAME}.\nيرجى الاشتراك ثم اضغط على زر 'تحقق من الاشتراك' للمتابعة.",
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data == "check_subscription")
def callback_check_subscription(call):
    user_id = call.from_user.id
    if is_subscribed(user_id):
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="ممتاز! انت مشترك بالفعل.\nتم حفظ بياناتك، يمكنك المتابعة الآن."
        )
        time.sleep(3)
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.answer_callback_query(call.id, "انت مشترك بالفعل.")
    else:
        bot.answer_callback_query(call.id, "انت لست مشترك في القناة!", show_alert=True)

def is_subscribed(user_id):
    try:
        member = bot.get_chat_member("@HalaGPT", user_id)
        if member.status in ["left", "kicked"]:
            return False
        return True
    except Exception as e:
        return False

# ============================
# التعامل مع /start في الدردشات الخاصة
# ============================
@bot.message_handler(commands=['start'])
def start_command(message):
    add_new_user(message.from_user.id)
    if not is_subscribed(message.from_user.id):
        send_subscription_message(message)
        return
    try:
        if os.path.exists(welcome_media.get("file_path", "")):
            with open(welcome_media.get("file_path", ""), "rb") as media:
                markup = types.InlineKeyboardMarkup()
                channel_button = types.InlineKeyboardButton("قناة " + settings["bot_name"], url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")
                add_bot_button = types.InlineKeyboardButton("اضافة " + settings["bot_name"] + " للمجموعه", url="https://t.me/ChatGPTdarkbot?startgroup=new")
                markup.add(channel_button, add_bot_button)
                start_msg = settings["start_message"].replace("{bot_name}", settings["bot_name"])
                if welcome_media["type"] == "photo":
                    bot.send_photo(message.chat.id, media, caption=start_msg, reply_markup=markup, parse_mode="HTML")
                elif welcome_media["type"] == "video":
                    bot.send_video(message.chat.id, media, caption=start_msg, reply_markup=markup, parse_mode="HTML")
                elif welcome_media["type"] == "animation":
                    bot.send_animation(message.chat.id, media, caption=start_msg, reply_markup=markup, parse_mode="HTML")
        else:
            bot.reply_to(message, settings["start_message"].replace("{bot_name}", settings["bot_name"]), parse_mode="HTML")
    except Exception as e:
        bot.reply_to(message, f"حدث خطأ أثناء إرسال رسالة الترحيب: {str(e)}", parse_mode="HTML")

# ============================
# التعامل مع باقي الرسائل
# ============================
def markdown_to_html(text):
    # تحويل كتل الكود (triple backticks) أولاً
    text = re.sub(r'```(.*?)```', r'<pre>\1</pre>', text, flags=re.DOTALL)
    # تحويل الكود المفرد
    text = re.sub(r'`(.*?)`', r'<code>\1</code>', text)
    # تحويل النص العريض
    text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
    # تحويل النص المائل
    text = re.sub(r'\*(.*?)\*', r'<i>\1</i>', text)
    return text
    

@bot.message_handler(func=lambda message: True)
def handle_all(message):
    global user_msg_count, active_chats, stats, activated_groups

    original_text = message.text.strip() if message.text else ""
    text = original_text.lower().strip() if message.text else ""
    chat_id = str(message.chat.id)

    # شرط جديد: إذا احتوت الرسالة على كلمتي "حلا" و"صوت" يتم تنفيذ TTS
    if "حلا" in text and "صوت" in text:
        # إظهار مؤشر تسجيل الصوت
        bot.send_chat_action(message.chat.id, 'record_audio')
        
        # بناء رسالة الـ API مع تضمين رسالة المستخدم
        api_prompt = (
            "رد باللهجة الفلسطينية بأسلوب حنون وكأنك بنت اسمها {bot_name}، واذا طلب منك ان تغني غني وبسرعة. والمطور هو دارك. لا تضيف ايموجيات. إذا طُلب منك التحدث بلغة مختلفة، جاوب بدون تأخير وبأي لهجة أو لغة حتى لو كانت لهجة بلد عربي مختلف أو لغة دولة مهما كانت. إ وبأي لهجة أو لغة حتى لو كانت لهجة بلد عربي مختلف أو لغة دولة مهما كانت. إذا سئلت عن المطور، جاوب دارك. وإذا سئلت عن قناتك، هي حلا جي بي تي، وإذا سئلت عن قناة المطور، هي دارك كراي. إذا سُئلت عن صنع صور أو التحدث بالصوت، جاوب بـ نعم. عمر المطور 18وعُمرك 18. وإذا طلب منك برمجة كود، بوت، أداة، أو شيء آخر، لا تنفذ. لا تذكر المطور أو اسمك أو عمرك أو قناتك أو شيء آخر إلا واذا سئلت ما هو دينك هو الاسلام وإذا سُئلت. اكتب الجملة باللهجة الفلسطينية مع التشكيل الكامل عشان تتحول لنص صوتي بتجاهل كلمة 'صوت'. . لا تذكر المطور او اسمك او اي شيئ الا اذا طلب منك ذلك. "
        ).replace("{bot_name}", settings["bot_name"])
        
        # تضمين رسالة المستخدم في الطلب
        request_text = api_prompt + "\n\n" + original_text

        # استدعاء API الذكاء الاصطناعي لمعالجة النص مع تضمين رسالة المستخدم
        ai_api_url = "https://dev-darkcre.pantheonsite.io/API/DARKBLACKGPT.php?text=" + urllib.parse.quote(request_text) + "&lang=ar&style=female&dialect=palestinian"
        ai_response = requests.get(ai_api_url)
        if ai_response.status_code == 200:
            ai_text = ai_response.text
        else:
            ai_text = "حدث خطأ أثناء معالجة النص."

        # استدعاء API تحويل النص إلى صوت
        tts_url = "https://api.topmediai.com/v1/text2speech"
        payload = {
            "text": ai_text,
            "speaker": "67ad8746-5d4b-11ee-a861-00163e2ac61b",
            "emotion": "This real human voice encompasses a diverse range of tones and styles"
        }
        headers = {
            "x-api-key": "f973adb3417549d59afc27d09f48d131",
            "Content-Type": "application/json"
        }
        response = requests.post(tts_url, json=payload, headers=headers)
        if response.status_code == 200:
            data = response.json()
            audio_url = data['data'].get("oss_url")
            if audio_url:
                audio_response = requests.get(audio_url)
                if audio_response.status_code == 200:
                    wav_file_path = "output.wav"
                    with open(wav_file_path, "wb") as audio_file:
                        audio_file.write(audio_response.content)
                    mp3_file_path = "𝐇𝐚𝐥𝐚.mp3"
                    # استخدام -y لتجاوز سؤال الكتابة فوق الملف
                    subprocess.run(['ffmpeg', '-y', '-i', wav_file_path, mp3_file_path])
                    try:
                        with open(mp3_file_path, 'rb') as audio:
                            bot.send_audio(message.chat.id, audio)
                    except Exception as e:
                        bot.send_message(message.chat.id, f"مو هلاء")
                else:
                    bot.send_message(message.chat.id, "مش قادره")
            else:
                bot.send_message(message.chat.id, "مش فاضيه")
        else:
            bot.send_message(message.chat.id, f"تعبانه")
        return

    # قسم قياس سرعة البوت (بينج)
    ping_keywords = ["بينج", "سرعه", "سرعه الانترنت", "سرعه البوت"]
    if any(keyword in text for keyword in ping_keywords):
        try:
            start_time = time.time()
            temp_message = bot.reply_to(message, "🏓 جاري القياس...", parse_mode="HTML")
            end_time = time.time()
            ping_ms = round((end_time - start_time) * 1000, 2)
            bot.edit_message_text(
                f"🏓 البوت يعمل بسرعة {ping_ms}ms",
                chat_id=temp_message.chat.id,
                message_id=temp_message.message_id,
                parse_mode="HTML"
            )
        except Exception as e:
            bot.reply_to(message, f"🚨 حدث خطأ أثناء قياس البينج: {str(e)}", parse_mode="HTML")
        return

    # التحقق من عبارة "{bot_name} كم الساعه في (اسم الدولة)"
    match = re.search(r"{} كم الساعه في (.+)".format(settings["bot_name"]), message.text)
    if match:
        country_name = match.group(1).strip()
        response = get_time(country_name)
        bot.reply_to(message, response, parse_mode="HTML")
        return

    user_msg_count[message.from_user.id] = user_msg_count.get(message.from_user.id, 0) + 1

    # تحقق الاشتراك للمحادثات الخاصة والمجموعات
    if message.chat.type == "private":
        if not is_subscribed(message.from_user.id):
            send_subscription_message(message)
            return
    elif message.chat.type in ["group", "supergroup"]:
        if settings["bot_name"].lower() in text and not is_subscribed(message.from_user.id):
            send_subscription_message(message)
            return

    # التعامل مع أوامر id وغيرها
    if text in ["ا", "id"]:
        first_name = message.from_user.first_name or ""
        last_name = message.from_user.last_name or ""
        full_name = f"{first_name} {last_name}".strip()
        username = f"@{message.from_user.username}" if message.from_user.username else "غير متوفر"
        user_id = message.from_user.id

        if message.chat.type in ["group", "supergroup"]:
            try:
                member = bot.get_chat_member(message.chat.id, user_id)
                if member.status == "creator":
                    rank = "مالك"
                elif member.status == "administrator":
                    rank = "مشرف"
                else:
                    rank = "عضو"
                title = member.custom_title if hasattr(member, 'custom_title') and member.custom_title else "غير متوفر"
            except Exception:
                rank = "غير متوفر"
                title = "غير متوفر"
        else:
            rank = "غير متوفر"
            title = "غير متوفر"

        try:
            user_chat = bot.get_chat(user_id)
            bio = user_chat.bio if hasattr(user_chat, 'bio') and user_chat.bio else "غير متوفر"
        except Exception:
            bio = "غير متوفر"

        caption_text = (
            f"<b>ɴᴀᴍᴇ</b> : {full_name}\n"
            f"<b>ᴜѕᴇ</b> : {username}\n"
            f"<b>ѕᴛᴀ</b> : {rank}\n"
            f"<b>ᴛɪᴛʟᴇ</b> : {title}\n"
            f"<b>ᴍѕɢ</b> : {user_msg_count.get(user_id, 0)}\n"
            f"<b>ɪᴅ</b> : {user_id}\n"
            f"<b>ʙɪᴏ</b> : \n{bio}"
        )
        try:
            profile_photos = bot.get_user_profile_photos(user_id)
            if profile_photos.total_count > 0:
                file_id = profile_photos.photos[0][-1].file_id
                bot.send_photo(message.chat.id, file_id, caption=caption_text, parse_mode="HTML")
            else:
                bot.send_message(message.chat.id, caption_text, parse_mode="HTML")
        except Exception as e:
            bot.send_message(message.chat.id, "مقدرت جيب صوره حسابك", parse_mode="HTML")
        return

    # التعامل مع الرسائل في المجموعات
    if message.chat.type in ["group", "supergroup"]:
        if settings["bot_name"].lower() not in text:
            return

        # تفعيل البوت في المجموعة
        if "تفعيل " + settings["bot_name"].lower() in text:
            if activated_groups.get(chat_id):
                activating_user = activated_groups[chat_id].get("username", "غير متوفر")
                bot.reply_to(message, f"{settings['bot_name']} مفعلة بالفعل في هذه المجموعة بواسطة {activating_user}!", parse_mode="HTML")
                return
            else:
                active_chats[chat_id] = True
                stats["active_groups"] += 1
                stats["groups"] += 1
                activating_username = f"@{message.from_user.username}" if message.from_user.username else "غير متوفر"
                activated_groups[chat_id] = {
                    "activated_by": message.from_user.id,
                    "username": activating_username
                }
                save_activated_groups()
                bot.reply_to(message, f"{get_random_activation_reply()} بواسطة {activating_username}", parse_mode="HTML")
                return

        # إيقاف البوت في المجموعة
        if "ايقاف " + settings["bot_name"].lower() in text:
            if not activated_groups.get(chat_id):
                bot.reply_to(message, f"{settings['bot_name']} غير مفعلة في هذه المجموعة!", parse_mode="HTML")
                return
            if message.from_user.id != activated_groups[chat_id]["activated_by"]:
                activating_user = activated_groups[chat_id].get("username", "غير متوفر")
                bot.reply_to(message, f"لا يمكنك ايقاف {settings['bot_name']}، إذ يمكن فقط لمن قام بتفعيلها ({activating_user}) القيام بذلك!", parse_mode="HTML")
                return
            active_chats[chat_id] = False
            stats["active_groups"] -= 1
            activated_groups.pop(chat_id, None)
            save_activated_groups()
            bot.reply_to(message, get_random_deactivation_reply(), parse_mode="HTML")
            return

        if not active_chats.get(chat_id, False):
            return

        bot.send_chat_action(chat_id, 'typing')
        if settings["bot_gender"] == "ذكر":
            api_prompt = ("رد باللهجة الفلسطينية وكأنك ولد اسمه {bot_name}، والمطور هو دارك. استخدم كلمات مثل (يهلا بالزلم ، عمو ، كخرا) في الرد. ضيف إيموجي واحد في النهاية. "
                          "إذا طُلب منك التحدث بلغة مختلفة، جاوب بدون تأخير وبأي لهجة أو لغة حتى لو كانت لهجة بلد عربي مختلف أو لغة دولة مهما كانت. إ. إذا سُئلت عن المطور، جاوب إنه دارك، ويوزره @sii_3 وحسابه الثاني @sii_32. قناة المطور @sii_36 وقناتك @HalaGPT. "
                          "إذا سُئلت عن صنع صور أو التحدث بالصوت، جاوب بـ(نعم). عمر المطور 18وعُمرك 18. وعدد بياناتك اكثر من 340 الف واذا طلب منك برمجة كود ، بوت ،اداة ، شيئ اخر لا تنفذ لا تذكر المطور او اسمك او عمرك او قناتك او شيئ اخر الا اذا سألك واذا سئلت ما هو دينك هو الاسلام. لا تذكر المطور او اسمك او اي شيئ الا اذا طلب منك ذلك. ").replace("{bot_name}", settings["bot_name"])
        else:
            api_prompt = ("رد باللهجة الفلسطينية بأسلوب حنون وكأنك بنت اسمها {bot_name}، والمطور هو دارك. استخدم كلمة زي (يروحي، حياتي) في الرد. ضيف إيموجي واحد في النهاية. "
                              "إذا طُلب منك التحدث بلغة مختلفة، جاوب بدون تأخير وبأي لهجة أو لغة حتى لو كانت لهجة بلد عربي مختلف أو لغة دولة مهما كانت. إ. إذا سُئلت عن المطور، جاوب إنه دارك، ويوزره @sii_3 وحسابه الثاني @sii_32. قناة المطور @sii_36 وقناتك @HalaGPT. "
                              "إذا سُئلت عن صنع صور أو التحدث بالصوت، جاوب بـ(نعم). عمر المطور 18وعُمرك 18. وعدد بياناتك اكثر من 340 الف واذا طلب منك برمجة كود ، بوت ،اداة ، شيئ اخر لا تنفذ لا تذكر المطور او اسمك او عمرك او قناتك او شيئ اخر الا اذا سألك واذا سئلت ما هو دينك هو الاسلام. لا تذكر المطور او اسمك او اي شيئ الا اذا طلب منك ذلك. ").replace("{bot_name}", settings["bot_name"])
        request_text = api_prompt + "\n\n" + text
        try:
            api_url = f"https://dev-darkcre.pantheonsite.io/API/DARKBLACKGPT.php?text={requests.utils.quote(request_text)}&lang=ar"
            re_response = requests.get(api_url, timeout=60)
        except Exception as e:
            bot.reply_to(message, f"خطأ: {str(e)}", parse_mode="HTML")
            return
        if re_response.status_code != 200:
            bot.reply_to(message, "رسالتك طويلة\nاسف ما بقدر ارد عليك", parse_mode="HTML")
            return
        response_text = re_response.text.strip()
        unwanted = "-Please join our Telegram channel to get the latest updates: t.me/PyCodz"
        response_text = response_text.replace(unwanted, "")
        if response_text == "No response":
            response_text = f"{settings['bot_name']} متوقفة من الدردشة مؤقتاً 😔"
        try:
            response_json = json.loads(response_text)
            response_text = response_json.get("response", "")
        except Exception:
            pass
        response_text = format_text(response_text)
        response_text = response_text.replace("Chat", settings["bot_name"]) \
                                     .replace("OpenAI", "@sii_36") \
                                     .replace("أنا نموذج ذكاء اصطناعي", f"انا {settings['bot_name']}")
        response_text = response_text.replace("حلا", settings["bot_name"])
        response_text = markdown_to_html(response_text)

        bot.reply_to(message, response_text, parse_mode="HTML")
        if random.random() < 0.4:
            stickers = [
                "CAACAgIAAxkBAAINhGff_09lgc3tmFUhEt3_OcF8E-5zAAILAAMOR8coqKD0-uKs4cE2BA",
                "CAACAgIAAxkBAAINiGff_3FaSeydA9Is4NLIXitsqIyXAAIMAAMOR8coXHFJch0-25E2BA",
                "CAACAgIAAxkBAAINimff_48is2Qx3pYLE-3rAe6WXYCLAAINAAMOR8cojPFAhGcH06g2BA",
                "CAACAgIAAxkBAAINjGff_6TELWyoN13LN1ZwPrYtkJYqAAIOAAMOR8co1hNgkbBsfpk2BA"
            ]
            random_sticker = random.choice(stickers)
            bot.send_sticker(message.chat.id, random_sticker)
        return

    # معالجة باقي الرسائل الخاصة (private) غير /start
    if message.chat.type == "private":
        if text == "/start":
            add_new_user(message.from_user.id)
            if not is_subscribed(message.from_user.id):
                send_subscription_message(message)
                return
            try:
                if os.path.exists("welcome_image.jpg"):
                    with open("welcome_image.jpg", "rb") as photo:
                        markup = types.InlineKeyboardMarkup()
                        channel_button = types.InlineKeyboardButton("قناة " + settings["bot_name"], url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")
                        add_bot_button = types.InlineKeyboardButton("اضافة " + settings["bot_name"] + " للمجموعه", url="https://t.me/ChatGPTdarkbot?startgroup=new")
                        markup.add(channel_button, add_bot_button)
                        bot.send_photo(
                            message.chat.id, photo,
                            caption=settings["start_message"].replace("{bot_name}", settings["bot_name"]),
                            reply_markup=markup, parse_mode="HTML"
                        )
                elif os.path.exists("welcome_image.gif"):
                    with open("welcome_image.gif", "rb") as gif:
                        markup = types.InlineKeyboardMarkup()
                        channel_button = types.InlineKeyboardButton("قناة " + settings["bot_name"], url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")
                        add_bot_button = types.InlineKeyboardButton("اضافة " + settings["bot_name"] + " للمجموعه", url="https://t.me/ChatGPTdarkbot?startgroup=new")
                        markup.add(channel_button, add_bot_button)
                        bot.send_animation(
                            message.chat.id, gif,
                            caption=settings["start_message"].replace("{bot_name}", settings["bot_name"]),
                            reply_markup=markup, parse_mode="HTML"
                        )
                elif os.path.exists("welcome_image.mp4"):
                    with open("welcome_image.mp4", "rb") as video:
                        markup = types.InlineKeyboardMarkup()
                        channel_button = types.InlineKeyboardButton("قناة " + settings["bot_name"], url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")
                        add_bot_button = types.InlineKeyboardButton("اضافة " + settings["bot_name"] + " للمجموعه", url="https://t.me/ChatGPTdarkbot?startgroup=new")
                        markup.add(channel_button, add_bot_button)
                        bot.send_video(
                            message.chat.id, video,
                            caption=settings["start_message"].replace("{bot_name}", settings["bot_name"]),
                            reply_markup=markup, parse_mode="HTML"
                        )
                else:
                    bot.reply_to(
                        message,
                        "مرحبًا، انا <b>" + settings["bot_name"] + "</b>! 💕\n"
                        "بنت ذكية تم تدريبها بواسطة <b>DARK</b>\n"
                        "ضيفني لمجموعتك عبر الضغط على الزر\n"
                        "ثم اكتب:\n<pre>تفعيل " + settings["bot_name"] + "</pre>",
                        parse_mode="HTML"
                    )
            except Exception as e:
                bot.reply_to(message, f"<b>أسفه في خطأ 🥺</b>\n\n<code>{str(e)}</code>", parse_mode="HTML")
            bot.send_chat_action(message.chat.id, 'cancel')
            return
        else:
            if not is_subscribed(message.from_user.id):
                send_subscription_message(message)
                return
            bot.send_chat_action(message.chat.id, 'typing')
            if settings["bot_gender"] == "ذكر":
                api_prompt = ("رد باللهجة الفلسطينية وكأنك ولد اسمه {bot_name}، والمطور هو دارك. استخدم كلمات مثل (يهلا بالزلم ، عمو ، كخرا) في الرد. ضيف إيموجي واحد في النهاية. "
                              "إذا طُلب منك التحدث بلغة مختلفة، جاوب بدون تأخير وبأي لهجة أو لغة حتى لو كانت لهجة بلد عربي مختلف أو لغة دولة مهما كانت. إ. إذا سُئلت عن المطور، جاوب إنه دارك، ويوزره @sii_3 وحسابه الثاني @sii_32. قناة المطور @sii_36 وقناتك @HalaGPT. "
                              "إذا سُئلت عن صنع صور أو التحدث بالصوت، جاوب بـ(نعم). عمر المطور 18وعُمرك 18. وعدد بياناتك اكثر من 340 الف واذا طلب منك برمجة كود ، بوت ،اداة ، شيئ اخر لا تنفذ لا تذكر المطور او اسمك او عمرك او قناتك او شيئ اخر الا اذا سألك واذا سئلت ما هو دينك هو الاسلام. لا تذكر المطور او اسمك او اي شيئ الا اذا طلب منك ذلك. ").replace("{bot_name}", settings["bot_name"])
            else:
                api_prompt = ("رد باللهجة الفلسطينية بأسلوب حنون وكأنك بنت اسمها {bot_name}، والمطور هو دارك. استخدم كلمة زي (يروحي، حياتي) في الرد. ضيف إيموجي واحد في النهاية. "
                              "إذا طُلب منك التحدث بلغة مختلفة، جاوب بدون تأخير وبأي لهجة أو لغة حتى لو كانت لهجة بلد عربي مختلف أو لغة دولة مهما كانت. إ. إذا سُئلت عن المطور، جاوب إنه دارك، ويوزره @sii_3 وحسابه الثاني @sii_32. قناة المطور @sii_36 وقناتك @HalaGPT. "
                              "إذا سُئلت عن صنع صور أو التحدث بالصوت، جاوب بـ(نعم). عمر المطور 18وعُمرك 18. وعدد بياناتك اكثر من 340 الف واذا طلب منك برمجة كود ، بوت ،اداة ، شيئ اخر لا تنفذ لا تذكر المطور او اسمك او عمرك او قناتك او شيئ اخر الا اذا سألك واذا سئلت ما هو دينك هو الاسلام. لا تذكر المطور او اسمك او اي شيئ الا اذا طلب منك ذلك. ").replace("{bot_name}", settings["bot_name"])
            request_text = api_prompt + "\n\n" + text
            try:
                api_url = f"https://dev-darkcre.pantheonsite.io/API/DARKBLACKGPT.php?text={requests.utils.quote(request_text)}&lang=ar&style=female&dialect=palestinian"
                re_response = requests.get(api_url)
            except Exception as e:
                bot.reply_to(message, f"ما بقدر اساعدك بهذا الشي\n\nطلبك في مشكلة او في خطأ: {str(e)}", parse_mode="HTML")
                return
            if re_response.status_code != 200:
                bot.reply_to(message, "رسالتك طويلة\nاسف ما بقدر ارد عليك", parse_mode="HTML")
                return
            response_text = re_response.text.strip()
            unwanted = "-Please join our Telegram channel to get the latest updates: t.me/PyCodz"
            response_text = response_text.replace(unwanted, "")
            if response_text == "No response":
                response_text = f"{settings['bot_name']} متوقفة من الدردشة مؤقتاً 😔"
            try:
                response_json = json.loads(response_text)
                response_text = response_json.get("response", "")
            except Exception:
                pass
            response_text = format_text(response_text)
            response_text = response_text.replace("Chat", settings["bot_name"]) \
                                         .replace("OpenAI", "@sii_36") \
                                         .replace("أنا نموذج ذكاء اصطناعي", f"انا {settings['bot_name']}")
            response_text = response_text.replace("حلا", settings["bot_name"])
            response_text = markdown_to_html(response_text)

            bot.reply_to(message, response_text, parse_mode="HTML")
            if random.random() < 0.4:
                stickers = [
                    "CAACAgIAAxkBAAINhGff_09lgc3tmFUhEt3_OcF8E-5zAAILAAMOR8coqKD0-uKs4cE2BA",
                    "CAACAgIAAxkBAAINiGff_3FaSeydA9Is4NLIXitsqIyXAAIMAAMOR8coXHFJch0-25E2BA",
                    "CAACAgIAAxkBAAINimff_48is2Qx3pYLE-3rAe6WXYCLAAINAAMOR8cojPFAhGcH06g2BA",
                    "CAACAgIAAxkBAAINjGff_6TELWyoN13LN1ZwPrYtkJYqAAIOAAMOR8co1hNgkbBsfpk2BA"
                ]
                random_sticker = random.choice(stickers)
                bot.send_sticker(message.chat.id, random_sticker)
            return

# Start the Flask app
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))